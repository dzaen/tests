#!/usr/bin/env bash
# fix-semgrep-venv.sh — чинит semgrep: "ModuleNotFoundError: No module named 'pkg_resources'".
#
# ПРИЧИНА: pkg_resources поставляется в составе setuptools, но в setuptools >= 81 его УДАЛИЛИ.
# Поэтому даже при установленном setuptools 82.x модуль pkg_resources отсутствует, а semgrep
# (через opentelemetry) его импортирует. Лечение: поставить setuptools<81 (там pkg_resources есть),
# либо доставить сам модуль pkg_resources офлайн. Пере-доставка всего bundle НЕ нужна.
#
#   ./fix-semgrep-venv.sh [VENV_DIR] [WHEELS_DIR]
set -o pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
TOOLKIT="$(cd "$HERE/.." && pwd)"
VENV="${1:-$TOOLKIT/sectools/venv}"
WHEELS="${2:-}"
[ -z "$WHEELS" ] && for c in "$TOOLKIT/bundle/wheels" "$HERE/bundle/wheels" "$TOOLKIT/sectools/wheels"; do
  [ -d "$c" ] && { WHEELS="$c"; break; }
done

log(){ echo "  $*"; }
[ -d "$VENV" ] || { echo "Не найден venv: $VENV (укажите путь первым аргументом)" >&2; exit 1; }
PY="$VENV/bin/python"; PIP="$VENV/bin/pip"
[ -x "$PY" ] || { echo "Нет $PY — это не venv?" >&2; exit 1; }

ok(){ "$PY" -c 'import pkg_resources' >/dev/null 2>&1; }
done_ok(){ log "OK ($1): pkg_resources доступен."; "$VENV/bin/semgrep" --version 2>/dev/null || true; exit 0; }

ok && done_ok "уже работает"

SETUP_VER="$("$PY" -c 'import setuptools;print(setuptools.__version__)' 2>/dev/null || echo '?')"
log "setuptools=$SETUP_VER, но pkg_resources отсутствует (удалён в setuptools>=81). Нужен setuptools<81."
VENV_SP="$("$PY" -c 'import sysconfig;print(sysconfig.get_paths()["purelib"])' 2>/dev/null)"

# 1) офлайн из bundle/wheels: setuptools<81
if [ -n "$WHEELS" ] && [ -d "$WHEELS" ]; then
  log "Пробую офлайн из $WHEELS: setuptools<81 …"
  "$PIP" install --no-index --find-links "$WHEELS" 'setuptools<81' >/dev/null 2>&1 && ok && done_ok "wheels"
fi

# 2) обычный pip (если есть индекс/зеркало/сеть)
log "Пробую pip install 'setuptools<81' …"
"$PIP" install 'setuptools<81' >/dev/null 2>&1 && ok && done_ok "pip"

# 3) полностью офлайн: скопировать pkg_resources из vendored-копии pip (есть в любом venv)
VEND="$VENV_SP/pip/_vendor/pkg_resources"
if [ -d "$VEND" ]; then
  log "Копирую pkg_resources из pip/_vendor …"
  cp -r "$VEND" "$VENV_SP/pkg_resources" 2>/dev/null && ok && done_ok "pip vendored"
fi

# 4) офлайн: скопировать pkg_resources из системного Python, где он ещё есть
for SYS in python3 /usr/bin/python3 /usr/local/bin/python3; do
  command -v "$SYS" >/dev/null 2>&1 || continue
  SYS_SP="$("$SYS" -c 'import sysconfig;print(sysconfig.get_paths()["purelib"])' 2>/dev/null)" || continue
  if [ -d "$SYS_SP/pkg_resources" ]; then
    log "Копирую pkg_resources из $SYS_SP …"
    cp -r "$SYS_SP/pkg_resources" "$VENV_SP/" 2>/dev/null
    [ -d "$SYS_SP/_distutils_hack" ] && cp -r "$SYS_SP/_distutils_hack" "$VENV_SP/" 2>/dev/null
    ok && done_ok "система $SYS"
  fi
done

echo "" >&2
echo "Не удалось доставить pkg_resources офлайн." >&2
echo "На машине с интернетом: pip download 'setuptools<81' -d wheels  → перенести → $0 \"$VENV\" wheels" >&2
echo "Либо использовать Docker-образ (база python:3.12 несёт setuptools с pkg_resources)." >&2
exit 1
