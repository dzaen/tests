#!/usr/bin/env bash
# install-tools.sh — ЗАПУСКАТЬ В ЗАКРЫТОМ КОНТУРЕ (Linux). Сети не требует.
# Ставит инструменты из bundle/ (созданного fetch-tools.sh) в локальный префикс
# sectools/ и пишет sectools/env.sh с PATH и путями к оффлайн-БД.
#
# Использование:
#   ./install-tools.sh [BUNDLE_DIR] [--prefix DIR]
#   (по умолчанию BUNDLE_DIR=./bundle, PREFIX=<корень тулкита>/sectools)
#
# После установки:
#   source sectools/env.sh   # или просто запускайте run-all.sh — он подхватит env сам
set -o pipefail

BUNDLE=""; PREFIX=""
while [ $# -gt 0 ]; do
  case "$1" in
    --prefix) PREFIX="$2"; shift 2;;
    -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
    *) BUNDLE="$1"; shift;;
  esac
done

HERE="$(cd "$(dirname "$0")" && pwd)"
TOOLKIT="$(cd "$HERE/.." && pwd)"      # install/ лежит внутри тулкита
[ -z "$BUNDLE" ] && BUNDLE="$PWD/bundle"
[ -d "$BUNDLE" ] || BUNDLE="$HERE/bundle"
[ -d "$BUNDLE" ] || { echo "Не найден каталог bundle. Укажите: ./install-tools.sh /path/to/bundle" >&2; exit 1; }
BUNDLE="$(cd "$BUNDLE" && pwd)"
[ -z "$PREFIX" ] && PREFIX="$TOOLKIT/sectools"

BIN="$PREFIX/bin"; SHARE="$PREFIX/share"; DBD="$SHARE/db"; VENV="$PREFIX/venv"
mkdir -p "$BIN" "$SHARE" "$DBD"

log(){ echo "  $*"; }
section(){ printf '\n\033[1m── %s ──\033[0m\n' "$1"; }

echo "=================================================="
echo " install-tools"
echo " Bundle: $BUNDLE"
echo " Prefix: $PREFIX"
echo "=================================================="

# проверка sha256 (если есть утилита и манифест)
if [ -f "$BUNDLE/MANIFEST.txt" ] && command -v sha256sum >/dev/null 2>&1; then
  section "Проверка целостности (sha256)"
  ( cd "$BUNDLE" && sha256sum -c --quiet MANIFEST.txt 2>/dev/null ) \
    && log "целостность OK" || log "(!) часть файлов не прошла sha256 — проверьте перенос bundle"
fi

# ───────── 1. статические бинари ─────────
section "Бинари"
if [ -d "$BUNDLE/binaries" ]; then
  for b in "$BUNDLE/binaries"/*; do
    [ -e "$b" ] || continue
    cp "$b" "$BIN/"; chmod +x "$BIN/$(basename "$b")"; log "✓ $(basename "$b")"
  done
else
  log "(нет bundle/binaries)"
fi

# ───────── 2. Python-инструменты (venv + wheels) ─────────
section "Python-инструменты (venv)"
if [ -d "$BUNDLE/wheels" ] && [ -n "$(ls -A "$BUNDLE/wheels" 2>/dev/null)" ]; then
  PY="$(command -v python3 || command -v python)"
  if [ -n "$PY" ]; then
    "$PY" -m venv "$VENV" 2>/dev/null || log "venv не создан (нужен python3-venv)"
    if [ -x "$VENV/bin/pip" ]; then
      # setuptools<81 + wheel СНАЧАЛА: без pkg_resources (есть только в setuptools<81) semgrep падает.
      "$VENV/bin/pip" install --no-index --find-links "$BUNDLE/wheels" pip 'setuptools<81' wheel 2>/dev/null \
        && log "✓ база: pip/setuptools<81/wheel" || log "(!) setuptools<81/wheel не найдены в wheels — semgrep может упасть на pkg_resources (см. fix-semgrep-venv.sh)"
      PKGS="$(tr '\n' ' ' < "$BUNDLE/PYPKGS.txt" 2>/dev/null)"
      [ -z "$PKGS" ] && PKGS="setuptools wheel semgrep"
      "$VENV/bin/pip" install --no-index --find-links "$BUNDLE/wheels" $PKGS \
        && log "✓ установлено: $PKGS" || log "! pip install не удался (проверьте совпадение версии Python/платформы wheels)"
      # быстрая самопроверка semgrep
      if [ -x "$VENV/bin/semgrep" ]; then
        "$VENV/bin/semgrep" --version >/dev/null 2>&1 && log "✓ semgrep импортируется" \
          || log "(!) semgrep установлен, но не запускается — проверьте setuptools в wheels"
      fi
    fi
  else
    log "нет python3 — Python-инструменты пропущены"
  fi
else
  log "(нет bundle/wheels)"
fi

# ───────── 3. Semgrep правила ─────────
section "Semgrep правила"
if [ -d "$BUNDLE/semgrep-rules" ]; then
  rm -rf "$SHARE/semgrep-rules"; cp -r "$BUNDLE/semgrep-rules" "$SHARE/semgrep-rules"
  log "✓ share/semgrep-rules"
else
  log "(нет bundle/semgrep-rules)"
fi

# ───────── 4. Оффлайн-БД ─────────
section "Базы данных (offline)"
for d in trivy grype osv dc-data; do
  if [ -d "$BUNDLE/db/$d" ]; then cp -r "$BUNDLE/db/$d" "$DBD/"; log "✓ db/$d"; fi
done

# ───────── 5. Java-инструменты (распаковка + врапперы) ─────────
section "Java-инструменты"
mkwrap(){ # mkwrap <name> <real_exec_path>
  { echo '#!/usr/bin/env bash'; echo "exec \"$2\" \"\$@\""; } > "$BIN/$1"
  chmod +x "$BIN/$1"; log "✓ wrapper: $1 -> $2"; }

unpack(){ # unpack <archive> <destdir>
  mkdir -p "$2"
  case "$1" in
    *.zip) unzip -qo "$1" -d "$2";;
    *.tgz|*.tar.gz) tar -xzf "$1" -C "$2";;
  esac
}

if [ -d "$BUNDLE/java" ]; then
  # PMD
  pmdzip="$(ls "$BUNDLE/java"/pmd-*.zip 2>/dev/null | head -1)"
  if [ -n "$pmdzip" ]; then unpack "$pmdzip" "$SHARE/pmd"
    pmdbin="$(find "$SHARE/pmd" -path '*/bin/pmd' | head -1)"
    [ -n "$pmdbin" ] && { chmod +x "$pmdbin"; mkwrap pmd "$pmdbin"; }
  fi
  # Dependency-Check
  dczip="$(ls "$BUNDLE/java"/dependency-check-*.zip 2>/dev/null | head -1)"
  if [ -n "$dczip" ]; then unpack "$dczip" "$SHARE/depcheck"
    dcbin="$(find "$SHARE/depcheck" -path '*/bin/dependency-check.sh' | head -1)"
    [ -n "$dcbin" ] && { chmod +x "$dcbin"; mkwrap dependency-check.sh "$dcbin"; }
  fi
  # SpotBugs + FindSecBugs
  sbtgz="$(ls "$BUNDLE/java"/spotbugs-*.tgz 2>/dev/null | head -1)"
  if [ -n "$sbtgz" ]; then unpack "$sbtgz" "$SHARE/spotbugs"
    sbbin="$(find "$SHARE/spotbugs" -path '*/bin/spotbugs' | head -1)"
    [ -n "$sbbin" ] && { chmod +x "$sbbin"; mkwrap spotbugs "$sbbin"; }
  fi
  fsb="$(ls "$BUNDLE/java"/findsecbugs-plugin-*.jar 2>/dev/null | head -1)"
  [ -n "$fsb" ] && { cp "$fsb" "$SHARE/"; FSB_PLUGIN="$SHARE/$(basename "$fsb")"; log "✓ findsecbugs plugin"; }
  # CodeQL
  cqtgz="$(ls "$BUNDLE/java"/codeql-bundle-*.tar.gz 2>/dev/null | head -1)"
  if [ -n "$cqtgz" ]; then unpack "$cqtgz" "$SHARE/codeql-bundle"
    cqbin="$(find "$SHARE/codeql-bundle" -type f -name codeql -path '*/codeql/codeql' | head -1)"
    [ -z "$cqbin" ] && cqbin="$(find "$SHARE/codeql-bundle" -type f -name codeql | head -1)"
    [ -n "$cqbin" ] && { chmod +x "$cqbin"; mkwrap codeql "$cqbin"; }
  fi
else
  log "(нет bundle/java)"
fi

# ───────── 6. env.sh ─────────
section "Запись env.sh"
ENVF="$PREFIX/env.sh"
{
  echo "# sectools env — source этот файл или просто запускайте run-all.sh"
  echo "export SECTOOLS_PREFIX=\"$PREFIX\""
  echo "export PATH=\"$BIN:$VENV/bin:\$PATH\""
  [ -d "$SHARE/semgrep-rules" ] && echo "export SEMGREP_RULES=\"$SHARE/semgrep-rules\""
  echo "export SEMGREP_SEND_METRICS=off"
  [ -d "$DBD/trivy" ]   && echo "export TRIVY_CACHE_DIR=\"$DBD/trivy\""
  [ -d "$DBD/grype" ]   && { echo "export GRYPE_DB_CACHE_DIR=\"$DBD/grype\""; echo "export GRYPE_DB_AUTO_UPDATE=false"; }
  [ -d "$DBD/osv" ]     && echo "export OSV_OFFLINE_DB=\"$DBD/osv\""
  [ -d "$DBD/dc-data" ] && echo "export DEPENDENCY_CHECK_DATA=\"$DBD/dc-data\""
  [ -n "${FSB_PLUGIN:-}" ] && echo "export FINDSECBUGS_PLUGIN=\"$FSB_PLUGIN\""
} > "$ENVF"
log "✓ $ENVF"

echo ""
echo "=================================================="
echo " Установлено в: $PREFIX"
echo " Инструменты:"; ls "$BIN" 2>/dev/null | sed 's/^/   - /'
echo ""
echo " Запуск аудита:"
echo "   bash $TOOLKIT/run-all.sh /path/to/code"
echo "   (run-all.sh сам подхватит $ENVF)"
echo "=================================================="
