#!/usr/bin/env bash
# fetch-tools.sh — ЗАПУСКАТЬ НА МАШИНЕ С ИНТЕРНЕТОМ (Linux x86_64).
# Скачивает инструменты, правила Semgrep и оффлайн-БД в ./bundle, считает sha256.
# Затем переносите весь каталог bundle/ в закрытый контур и запускайте install-tools.sh.
#
# Использование:
#   ./fetch-tools.sh                 # базовый набор: ripgrep semgrep semgrep-rules gitleaks trivy depcheck
#   ./fetch-tools.sh --all           # всё, включая extra (trufflehog osv grype pmd spotbugs codeql ...)
#   ./fetch-tools.sh --only "ripgrep gitleaks semgrep semgrep-rules"
#   ./fetch-tools.sh --skip "depcheck"
#   PROJECT_DIR=/path/to/code ./fetch-tools.sh --all   # для osv/depcheck-БД по реальным зависимостям
#
# Переменные окружения:
#   PY_VER=3.11 PLATFORM=manylinux2014_x86_64   # под Python/арх контура (для pip wheels)
#   NVD_API_KEY=...                              # ускоряет загрузку базы Dependency-Check
set -o pipefail

# ───────── ВЕРСИИ (проверьте актуальные перед запуском) ─────────
V_RIPGREP="14.1.1"
V_GITLEAKS="8.21.2"
V_TRUFFLEHOG="3.82.13"
V_TRIVY="0.56.2"
V_GRYPE="0.82.0"
V_SYFT="1.14.0"
V_OSV="1.9.1"
V_PMD="7.7.0"
V_DEPCHECK="11.1.0"
V_SPOTBUGS="4.8.6"
V_FINDSECBUGS="1.13.0"
# CodeQL bundle тянем по тегу 'latest' через redirect API.

# ВАЖНО: setuptools<81 + wheel обязательны. Python 3.12+ venv не ставит setuptools, а semgrep
# (через opentelemetry) требует pkg_resources. В setuptools>=81 pkg_resources УДАЛЁН — поэтому
# именно <81 (там модуль ещё есть). `<` внутри переменной не трактуется как редирект при разворачивании.
PYPKGS_BASE="pip setuptools<81 wheel"
PYPKGS_DEFAULT="$PYPKGS_BASE semgrep"
PYPKGS_EXTRA="njsscan detect-secrets"

BUNDLE="$(pwd)/bundle"
BIN="$BUNDLE/binaries"; JAVA="$BUNDLE/java"; WHEELS="$BUNDLE/wheels"
RULES="$BUNDLE/semgrep-rules"; DB="$BUNDLE/db"; TMP="$BUNDLE/.tmp"
MANIFEST="$BUNDLE/MANIFEST.txt"

# ───────── разбор аргументов ─────────
MODE="default"; ONLY=""; SKIP=""
while [ $# -gt 0 ]; do
  case "$1" in
    --all) MODE="all"; shift;;
    --only) ONLY="$2"; shift 2;;
    --skip) SKIP="$2"; shift 2;;
    -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
    *) echo "неизвестный аргумент: $1" >&2; exit 1;;
  esac
done

DEFAULT_SET="ripgrep semgrep semgrep-rules gitleaks trivy depcheck"
ALL_SET="$DEFAULT_SET trufflehog osv grype syft pmd spotbugs codeql pytools-extra"
case "$MODE" in
  all) SET="$ALL_SET";;
  *)   SET="${ONLY:-$DEFAULT_SET}";;
esac

want(){
  local t="$1"
  echo " $SET " | grep -q " $t " || return 1
  [ -n "$SKIP" ] && echo " $SKIP " | grep -q " $t " && return 1
  return 0
}

mkdir -p "$BIN" "$JAVA" "$WHEELS" "$DB" "$TMP"
: > "$MANIFEST"

err(){ echo "  ! $*" >&2; }
log(){ echo "  $*"; }
record(){ # record <file> — пишем ОТНОСИТЕЛЬНЫЙ путь (от bundle/), чтобы проверка работала в контуре
  if command -v sha256sum >/dev/null 2>&1 && [ -f "$1" ]; then
    ( cd "$BUNDLE" && sha256sum "${1#"$BUNDLE"/}" ) >> "$MANIFEST"
  fi
}
dl(){ # dl <url> <out>
  local url="$1" out="$2"
  log "↓ $url"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --connect-timeout 30 -o "$out" "$url" || { err "не скачан: $url"; return 1; }
  elif command -v wget >/dev/null 2>&1; then
    wget -q -O "$out" "$url" || { err "не скачан: $url"; return 1; }
  else
    err "нет ни curl, ни wget"; return 1
  fi
}
extract_binary(){ # extract_binary <archive> <binary_name_inside> <dest_name>
  local arc="$1" inside="$2" dest="${3:-$2}" d="$TMP/x.$$"; rm -rf "$d"; mkdir -p "$d"
  case "$arc" in
    *.tar.gz|*.tgz) tar -xzf "$arc" -C "$d" ;;
    *.zip)          unzip -qo "$arc" -d "$d" ;;
    *)              cp "$arc" "$d/$inside" ;;
  esac
  local found; found="$(find "$d" -type f -name "$inside" | head -1)"
  if [ -z "$found" ]; then err "в архиве не найден $inside"; rm -rf "$d"; return 1; fi
  cp "$found" "$BIN/$dest"; chmod +x "$BIN/$dest"; record "$BIN/$dest"; rm -rf "$d"
  log "✓ binaries/$dest"
}

GH="https://github.com"

# ───────── статические бинари ─────────
fetch_ripgrep(){ want ripgrep || return 0
  local f="$TMP/rg.tgz"
  dl "$GH/BurntSushi/ripgrep/releases/download/$V_RIPGREP/ripgrep-$V_RIPGREP-x86_64-unknown-linux-musl.tar.gz" "$f" \
    && extract_binary "$f" "rg" "rg"; }
fetch_gitleaks(){ want gitleaks || return 0
  local f="$TMP/gitleaks.tgz"
  dl "$GH/gitleaks/gitleaks/releases/download/v$V_GITLEAKS/gitleaks_${V_GITLEAKS}_linux_x64.tar.gz" "$f" \
    && extract_binary "$f" "gitleaks" "gitleaks"; }
fetch_trufflehog(){ want trufflehog || return 0
  local f="$TMP/trufflehog.tgz"
  dl "$GH/trufflesecurity/trufflehog/releases/download/v$V_TRUFFLEHOG/trufflehog_${V_TRUFFLEHOG}_linux_amd64.tar.gz" "$f" \
    && extract_binary "$f" "trufflehog" "trufflehog"; }
fetch_trivy(){ want trivy || return 0
  local f="$TMP/trivy.tgz"
  dl "$GH/aquasecurity/trivy/releases/download/v$V_TRIVY/trivy_${V_TRIVY}_Linux-64bit.tar.gz" "$f" \
    && extract_binary "$f" "trivy" "trivy" \
    && fetch_trivy_db; }
fetch_trivy_db(){
  log "Trivy: загрузка оффлайн-БД (vuln + java)…"
  "$BIN/trivy" --cache-dir "$DB/trivy" fs --download-db-only 2>/dev/null || err "trivy db download не удался"
  "$BIN/trivy" --cache-dir "$DB/trivy" fs --download-java-db-only 2>/dev/null || true
}
fetch_grype(){ want grype || return 0
  local f="$TMP/grype.tgz"
  dl "$GH/anchore/grype/releases/download/v$V_GRYPE/grype_${V_GRYPE}_linux_amd64.tar.gz" "$f" \
    && extract_binary "$f" "grype" "grype" \
    && { log "Grype: загрузка БД…"; GRYPE_DB_CACHE_DIR="$DB/grype" "$BIN/grype" db update || err "grype db update не удался"; }; }
fetch_syft(){ want syft || return 0
  local f="$TMP/syft.tgz"
  dl "$GH/anchore/syft/releases/download/v$V_SYFT/syft_${V_SYFT}_linux_amd64.tar.gz" "$f" \
    && extract_binary "$f" "syft" "syft"; }
fetch_osv(){ want osv || return 0
  dl "$GH/google/osv-scanner/releases/download/v$V_OSV/osv-scanner_linux_amd64" "$BIN/osv-scanner" \
    && { chmod +x "$BIN/osv-scanner"; record "$BIN/osv-scanner"; log "✓ binaries/osv-scanner"; }
  if [ -n "${PROJECT_DIR:-}" ] && [ -d "$PROJECT_DIR" ]; then
    log "OSV: загрузка оффлайн-БД по зависимостям из $PROJECT_DIR…"
    "$BIN/osv-scanner" --experimental-offline --experimental-download-offline-databases \
      --experimental-local-db-path "$DB/osv" -r "$PROJECT_DIR" >/dev/null 2>&1 || \
      err "osv offline-db: задайте PROJECT_DIR с lock-файлами"
  else
    err "OSV: PROJECT_DIR не задан — оффлайн-БД пропущена (osv-scanner без БД офлайн не работает)"
  fi; }

# ───────── Java-инструменты (архивы как есть, install распакует) ─────────
fetch_pmd(){ want pmd || return 0
  dl "$GH/pmd/pmd/releases/download/pmd_releases%2F$V_PMD/pmd-dist-$V_PMD-bin.zip" "$JAVA/pmd-$V_PMD.zip" && record "$JAVA/pmd-$V_PMD.zip"; }
fetch_depcheck(){ want depcheck || return 0
  dl "$GH/dependency-check/DependencyCheck/releases/download/v$V_DEPCHECK/dependency-check-$V_DEPCHECK-release.zip" "$JAVA/dependency-check-$V_DEPCHECK.zip" \
    && record "$JAVA/dependency-check-$V_DEPCHECK.zip" \
    && fetch_depcheck_db; }
fetch_depcheck_db(){
  log "Dependency-Check: наполнение базы NVD (нужна Java)…"
  command -v java >/dev/null 2>&1 || { err "нет java — пропуск NVD-базы (запустите --updateonly на машине с java)"; return 0; }
  local d="$TMP/dc"; rm -rf "$d"; mkdir -p "$d"; unzip -qo "$JAVA/dependency-check-$V_DEPCHECK.zip" -d "$d"
  local sh; sh="$(find "$d" -name dependency-check.sh -path '*/bin/*' | head -1)"
  [ -z "$sh" ] && { err "не найден dependency-check.sh"; return 0; }
  chmod +x "$sh"
  "$sh" --updateonly --data "$DB/dc-data" ${NVD_API_KEY:+--nvdApiKey "$NVD_API_KEY"} \
    || err "обновление NVD не удалось (нужен NVD_API_KEY и время)"; }
fetch_spotbugs(){ want spotbugs || return 0
  dl "$GH/spotbugs/spotbugs/releases/download/$V_SPOTBUGS/spotbugs-$V_SPOTBUGS.tgz" "$JAVA/spotbugs-$V_SPOTBUGS.tgz" && record "$JAVA/spotbugs-$V_SPOTBUGS.tgz"
  dl "https://repo1.maven.org/maven2/com/h3xstream/findsecbugs/findsecbugs-plugin/$V_FINDSECBUGS/findsecbugs-plugin-$V_FINDSECBUGS.jar" "$JAVA/findsecbugs-plugin-$V_FINDSECBUGS.jar" \
    && record "$JAVA/findsecbugs-plugin-$V_FINDSECBUGS.jar"; }
fetch_codeql(){ want codeql || return 0
  # codeql-bundle включает CLI + query packs (java/javascript)
  dl "$GH/github/codeql-action/releases/latest/download/codeql-bundle-linux64.tar.gz" "$JAVA/codeql-bundle-linux64.tar.gz" \
    && record "$JAVA/codeql-bundle-linux64.tar.gz"; }

# ───────── Semgrep правила (git) ─────────
fetch_semgrep_rules(){ want semgrep-rules || return 0
  if command -v git >/dev/null 2>&1; then
    rm -rf "$RULES"
    log "Semgrep rules: git clone…"
    git clone --depth 1 https://github.com/semgrep/semgrep-rules "$RULES" || err "git clone semgrep-rules не удался"
    rm -rf "$RULES/.git"
  else
    err "нет git — semgrep-rules пропущены (скачайте zip репозитория вручную в bundle/semgrep-rules)"
  fi; }

# ───────── pip wheels (Python-инструменты) ─────────
fetch_pywheels(){
  local pkgs="$1"
  command -v pip3 >/dev/null 2>&1 || command -v pip >/dev/null 2>&1 || { err "нет pip — wheels пропущены"; return 0; }
  local PIP; PIP="$(command -v pip3 || command -v pip)"
  local args=(download -d "$WHEELS" $pkgs)
  if [ -n "${PLATFORM:-}" ] && [ -n "${PY_VER:-}" ]; then
    args=(download -d "$WHEELS" --only-binary=:all: --platform "$PLATFORM" --python-version "$PY_VER" $pkgs)
    log "pip wheels под $PLATFORM / py$PY_VER: $pkgs"
  else
    log "pip wheels (native; запускайте на ОС/Python контура!): $pkgs"
  fi
  "$PIP" "${args[@]}" || err "pip download не удался для: $pkgs"
  echo "$pkgs" >> "$BUNDLE/PYPKGS.txt"; }
fetch_semgrep(){ want semgrep || return 0; fetch_pywheels "$PYPKGS_DEFAULT"; }
fetch_pytools_extra(){ want pytools-extra || return 0; fetch_pywheels "$PYPKGS_EXTRA"; }

echo "=================================================="
echo " fetch-tools — набор: $SET"
echo " Bundle: $BUNDLE"
echo "=================================================="
: > "$BUNDLE/PYPKGS.txt"

fetch_ripgrep
fetch_gitleaks
fetch_trufflehog
fetch_trivy
fetch_grype
fetch_syft
fetch_osv
fetch_pmd
fetch_depcheck
fetch_spotbugs
fetch_codeql
fetch_semgrep_rules
fetch_semgrep
fetch_pytools_extra

rm -rf "$TMP"
echo ""
echo "Готово. Содержимое bundle:"
du -sh "$BUNDLE"/* 2>/dev/null || ls -la "$BUNDLE"
echo ""
echo "MANIFEST (sha256): $MANIFEST"
echo "Перенесите весь каталог bundle/ в контур и запустите: ./install-tools.sh /path/to/bundle"
