#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Генератор rules.json и METHODOLOGY.md из выверенного набора правил.

Это ОДНОРАЗОВЫЙ инструмент сборки. Готовый артефакт — rules.json — самодостаточен;
его можно редактировать руками и расширять. Скрипт нормализует regex'ы, применяет
правки ревью (снижение severity / сужение шумных правил), дедуплицирует и собирает
методологию (инструменты + чеклисты) в Markdown.
"""
import json, re, os, sys, collections

HERE = os.path.dirname(os.path.abspath(__file__))
# Источник: сырой результат воркфлоу. Можно переопределить первым аргументом.
DEFAULT_SRC = r"C:\Users\Cross\AppData\Local\Temp\claude\e--02-Work-03-VibeCode-motorica\6af26960-6651-498b-bf14-9421dd7b2e95\tasks\w61beur6s.output"
SRC = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_SRC

PROVENANCE = os.path.join(HERE, "_ruleset_source.json")
RULES_OUT = os.path.join(HERE, "rules.json")
METH_OUT = os.path.join(HERE, "METHODOLOGY.md")

SEV_RANK = {"critical": 5, "high": 4, "medium": 3, "low": 2, "info": 1}

# Категории/домены, в которых совпадения трактуются как секреты (для редактирования
# вывода и фильтра ложных срабатываний в сканере).
SECRET_HINTS = ("secret", "credential", "password", "token", "api", "key", "creds")

# Правки по итогам ревью (completeness critic). Снижаем severity у шумных правил,
# сужаем языки, добавляем подсказку по триажу. id, которых нет, просто игнорируются.
OVERRIDES = {
    "spring-permitall-anyrequest": {"severity": "low",
        "triage": "Одиночный permitAll() часто легитимен (логин, статика, /health). Подозрителен anyRequest().permitAll() / общий all-allow."},
    "java-path-traversal-file-apis": {"severity": "low",
        "triage": "Шумно. Реальный риск — когда путь приходит из request/param/getParameter и нет нормализации/whitelist."},
    "java-ssrf-http-clients": {"severity": "medium",
        "triage": ".get/.post/.exchange широки; интересны вызовы с пользовательским URL."},
    "node-missing-helmet": {"severity": "info",
        "triage": "Информация (нет helmet), не уязвимость. Проверяйте bootstrap приложения вручную."},
    "node-cors-wildcard-credentials": {"severity": "info",
        "triage": "Голый cors() сам по себе не уязвим. Ищите origin:'*' вместе с credentials:true."},
    "node-insecure-cookie-flags": {"severity": "low",
        "triage": "Интересно только httpOnly:false / secure:false / отсутствие sameSite."},
    "jdbc-create-statement": {"severity": "low",
        "triage": "Сам по себе не уязвим. Смотрите, какой SQL уходит в execute* (конкатенация?)."},
    "java-insecure-random": {"severity": "low",
        "triage": "Опасно рядом с token/secret/id/salt/password/nonce; иначе обычно FP."},
    "jwt-none-alg-and-secret": {"severity": "medium",
        "triage": ".verify( широк; цель — alg=none или захардкоженный секрет подписи."},
    "meta-disabled-security-control": {"severity": "medium",
        "triage": "Значения 0/* дают FP (timeout=0, version=0). Полезно как sweep, не как готовая находка."},
    "node-jwt-algorithm-none": {"severity": "low",
        "triage": "Lookahead ненадёжен (FP/FN). Проверяйте опцию algorithms вручную."},
    "node-prototype-pollution-merge": {"severity": "medium",
        "triage": "merge/extend ловится широко; интересен merge/_.merge с req.body/JSON входом."},
    "secrets-in-web-storage": {"severity": "low",
        "triage": "Ловит присваивания .token=, не обязательно Storage. Проверяйте реальный localStorage/sessionStorage."},

    # ── точечная борьба с подтверждёнными классами FP (по результатам реального скана) ──
    # MyBatis ${} срабатывал на Maven-плейсхолдерах в pom.xml и JSP-EL — ограничиваем мапперами/DAO/.java.
    "mybatis-dollar-interpolation": {"severity": "medium", "languages": ["java", "xml"],
        "path_include": r"(?i)(mapper|sqlmap|ibatis|/dao/|\.java$)",
        "triage": "Только MyBatis-мапперы (mapper/sqlmap/ibatis/dao) и @Select/@Update в .java. pom.xml/JSP/web.xml исключены."},
    # innerHTML со статическим литералом — не XSS; требуем переменную/конкатенацию/шаблон.
    "dom-innerhtml-assignment": {
        "regex": r"\.(?:inner|outer)HTML\s*\+?=\s*(?:`[^`]*\$\{|[A-Za-z_$][\w$.\[\]()]*|[\x27\"][^\x27\"\n]*[\x27\"]\s*\+)",
        "triage": "Срабатывает только при переменной/конкатенации/шаблоне в правой части (статические строки игнорируются)."},
    # setTimeout/Interval опасен только со СТРОКОЙ первым аргументом (не с функцией).
    "js-settimeout-string": {
        "regex": r"\bset(?:Timeout|Interval)\s*\(\s*[\x27\"`]",
        "triage": "Флагуем только строковый первый аргумент (eval-подобное); setTimeout(func, ms) игнорируется."},
    # prototype pollution: только реальные sink'и (lodash _.merge/_.set, $.extend(true)); не Map.set().
    "prototype-pollution-merge": {"severity": "medium",
        "regex": r"\b_\.(?:merge|mergeWith|defaultsDeep|setWith|set)\s*\(|\bmergeWith\s*\(|\bdefaultsDeep\s*\(|\$\.extend\s*\(\s*true\b",
        "triage": "Только lodash _.merge/_.set/… и $.extend(true,…); обычный Map.set()/массивы не считаются."},
    # \b у ключевых слов: 'iv'/'salt' не должны ловиться внутри слов (http-equiv); html исключаем.
    "hardcoded-crypto-salt-iv": {
        "regex": r"\b(?:salt|iv|secret[_-]?key|encryption[_-]?key|hmac[_-]?key|signing[_-]?key)\b\s*[:=]\s*(?:[\x27\"][^\x27\"\s${}]{8,}[\x27\"]|new\s+byte\[\]\s*\{[^}]+\}|Buffer\.from\([\x27\"][0-9a-fA-F]{16,}[\x27\"])",
        "path_exclude": r"(?i)\.html?$",
        "triage": "Слово целиком (не внутри equiv и т.п.); HTML исключён."},
    # http:// в namespace/schemaLocation — не транспорт; расширяем список схемных хостов.
    "meta-insecure-transport-url": {"severity": "low",
        "regex": r"[\x27\"`]http://(?!localhost|127\.0\.0\.1|0\.0\.0\.0|schemas?\.|[^\x27\"`]*\.w3\.org|xmlns|maven\.apache\.org|java\.sun\.com|jcp\.org|jboss|springframework\.org|tomcat\.apache\.org|xml\.org|purl\.org|relaxng\.org|slf4j\.org|ns\.adobe)[A-Za-z0-9.\-]+",
        "triage": "Исключены namespace/schemaLocation-хосты; реальный http-endpoint — проверить вручную."},
    # reflection: высокий сигнал только при Class.forName(<переменная>) / getDeclaredMethod(<переменная>); не бин-маппинг.
    "reflection-class-forname-newinstance": {"severity": "low",
        "regex": r"\bClass\.forName\s*\(\s*[A-Za-z_$][\w$]*\s*[,)]|\.getDeclaredMethod\s*\(\s*[A-Za-z_$][\w$]*\s*[,)]",
        "triage": "Только динамическая загрузка класса/метода по переменной; JAXB/бин-маппинг и .invoke() исключены."},
}

# ────────────────────────────────────────────────────────────────────────────
# Рукописные правила: контроль доступа / IDOR / доверие к данным запроса.
# Доминирующий реальный класс в аудитах — broken access control. Греп НЕ доказывает
# IDOR (это семантика владения объектом), поэтому здесь всё low/medium и по факту
# needs-review: правила помечают КАНДИДАТОВ, а triage объясняет, что подтвердить.
# Добавляются в ruleset как есть (после нормализации/дедупа), переживают регенерацию.
# ────────────────────────────────────────────────────────────────────────────
EXTRA_RULES = [
    {
        "id": "authz-roles-from-request-header",
        "title": "Роли/идентичность берутся из HTTP-заголовка запроса (Java)",
        "severity": "medium", "languages": ["java"], "category": "access-control",
        "ignore_case": True,
        "regex": r"getheaders\s*\(\s*\)\s*\.\s*(?:get|getordefault|getfirst|getall)\s*\([^)]*(?:role|grant|scope|principal|tenant|user|login)",
        "why": "Решение об авторизации опирается на значение из заголовка запроса (роли/субъект). Если заголовок не выставляется доверенным слоем аутентификации (JWT-фильтр/шлюз) с затиранием клиентского значения — клиент подделывает себе роли: обход доступа и эскалация привилегий.",
        "remediation": "Бери роли/субъекта из проверенного JWT/сессии (SecurityContext), а не из сырого заголовка. Доверенный слой (@Priority(AUTHENTICATION) или шлюз) должен ПЕРЕЗАПИСЫВАТЬ этот заголовок и вырезать входящий от клиента.",
        "false_positives": "Если перед сервисом стоит шлюз/фильтр, который аутентифицирует и сам ставит заголовок из токена (а клиентский режется) — легитимный паттерн (FP на уровне приложения).",
        "triage": "Развилка: (1) есть @Priority(AUTHENTICATION)-фильтр/шлюз, делающий getHeaders().putSingle(<этот заголовок>, рольИзJWT)? -> FP. (2) сервис достижим напрямую мимо шлюза? -> реальный обход. Проверь: curl -H '<header>: Admin' напрямую на порт сервиса.",
    },
    {
        "id": "authz-identity-from-header-literal",
        "title": "getHeader(\"...\") c identity/role-заголовком (Java)",
        "severity": "medium", "languages": ["java"], "category": "access-control",
        "ignore_case": True,
        "regex": r"getheader\s*\(\s*[\x27\"][^\x27\"]*(?:role|user|login|principal|group|scope|tenant|remote[_-]?user|on[_-]?behalf|impersonat|isadmin|admin)",
        "why": "Идентичность/роль/субъект читается из произвольного HTTP-заголовка. Заголовки полностью контролируются клиентом — если их не санирует доверенный шлюз, это основа обхода авторизации.",
        "remediation": "Не доверяй identity-заголовкам от клиента; источник — подписанный токен/сессия. Шлюз обязан вырезать входящие X-User/X-Roles и ставить свои.",
        "false_positives": "Заголовок выставляется доверенным reverse-proxy/шлюзом, клиентский вырезается.",
        "triage": "Проверь, кто ставит заголовок и режется ли клиентский на периметре.",
    },
    {
        "id": "authz-decision-call",
        "title": "Вызов проверки прав — проверь источник субъекта (Java)",
        "severity": "low", "languages": ["java"], "category": "access-control",
        "ignore_case": True,
        "regex": r"\b(?:isauthor(?:ity|ized)|hasrole|hasanyrole|hasauthority|hasanyauthority|isuserinrole|checkpermission|ispermitted|isallowed|canaccess|haspermission|checkaccess)\s*\(",
        "why": "Точка принятия решения о доступе. Сама по себе не уязвима, но если субъект/роль для проверки берётся из запроса (а не из проверенного токена) — это обход.",
        "remediation": "Аргумент-субъект должен происходить из аутентифицированного принципала, не из параметров/заголовков запроса.",
        "false_positives": "Большинство вызовов легитимны (субъект из SecurityContext).",
        "triage": "Трассируй аргумент роли/субъекта: request -> обход; SecurityContext/JWT -> ок.",
    },
    {
        "id": "idor-rest-id-param",
        "title": "REST-параметр — идентификатор объекта (кандидат IDOR, Java)",
        "severity": "low", "languages": ["java"], "category": "access-control",
        "ignore_case": True,
        "regex": r"@(?:pathparam|queryparam|formparam|requestparam|pathvariable|matrixparam)\s*\(\s*[\x27\"][^\x27\"]*(?:\bid\b|uuid|guid|\bpk\b|login|[a-z_]*id)\b",
        "why": "Идентификатор объекта приходит из запроса. В связке с прямым доступом к объекту по этому id без проверки владельца — горизонтальный IDOR (доступ к чужим данным).",
        "remediation": "Сопоставляй объект с владельцем из токена/сессии или фильтруй выборку scope текущего пользователя (WHERE owner = :currentUser).",
        "false_positives": "Привязка id сама по себе легитимна; FP, если есть проверка владения или объект общий/справочный.",
        "triage": "Эскалируй, если рядом idor-direct-object-lookup и НЕТ проверки owner==currentUser.",
    },
    {
        "id": "idor-direct-object-lookup",
        "title": "Прямое получение объекта по id (sink IDOR, Java)",
        "severity": "low", "languages": ["java"], "category": "access-control",
        "ignore_case": True,
        "regex": r"\b(?:findbyid|getbyid|getone|getreferencebyid|getreference|readbyid|loadbyid)\s*\(|\b(?:entitymanager|em|session)\s*\.\s*(?:find|getreference|load|get)\s*\(|\.findone\s*\(",
        "why": "Прямая загрузка объекта по идентификатору. С request-controlled id и без проверки владельца — классический IDOR.",
        "remediation": "После загрузки проверяй принадлежность объекта текущему пользователю, либо фильтруй по владельцу в самом запросе.",
        "false_positives": "Повсеместный паттерн; сам по себе не уязвим.",
        "triage": "Низкий приоритет в одиночку. Эскалируй в связке с idor-rest-id-param и отсутствием owner-check.",
    },
    {
        "id": "mass-assignment-bean-java",
        "title": "Mass assignment: копирование свойств / привязка модели (Java)",
        "severity": "low", "languages": ["java"], "category": "access-control",
        "ignore_case": True,
        "regex": r"\b(?:beanutils|propertyutils)\s*\.\s*(?:copyproperties|populate)\s*\(|@modelattribute\b",
        "why": "Массовое присваивание полей из запроса может перезаписать поля, которые пользователь менять не должен (роль, владелец, флаги). Эскалация привилегий через лишние поля.",
        "remediation": "Используй DTO с явным allowlist полей; не привязывай тело запроса прямо к сущности; игнорируй чувствительные поля при биндинге.",
        "false_positives": "copyProperties между внутренними DTO — обычно ок.",
        "triage": "Проверь, не попадают ли в маппинг чувствительные поля (role/owner/isAdmin/enabled).",
    },
    {
        "id": "idor-request-id-source-js",
        "title": "req.params/query/body.id — идентификатор из запроса (Node)",
        "severity": "low", "languages": ["js"], "category": "access-control",
        "ignore_case": True,
        "regex": r"\breq(?:uest)?\.(?:params|query|body)\.(?:id|_id|uuid|guid|pk|[a-z_]*id)\b",
        "why": "Идентификатор объекта приходит из запроса; в связке с прямой выборкой без проверки владельца — IDOR.",
        "remediation": "Ограничивай выборку владельцем из сессии/токена (WHERE owner = req.user.id), не доверяй id из запроса для доступа.",
        "false_positives": "Сам по себе не уязвим; зависит от наличия проверки владения.",
        "triage": "Эскалируй в связке с idor-object-lookup-js без проверки req.user.",
    },
    {
        "id": "idor-object-lookup-js",
        "title": "Прямая выборка по id (Mongoose/ORM) — sink IDOR (Node)",
        "severity": "low", "languages": ["js"], "category": "access-control",
        "ignore_case": True,
        "regex": r"\.(?:findbyid|findbyidandupdate|findbyidandremove|findbyidanddelete|findbypk|findone)\s*\(",
        "why": "Прямое получение/изменение объекта по id. С request-controlled id и без фильтра по владельцу — IDOR.",
        "remediation": "Добавляй в запрос владельца: Model.findOne({_id:id, owner:req.user.id}); проверяй принадлежность после загрузки.",
        "false_positives": "Повсеместно; зависит от owner-check.",
        "triage": "Эскалируй с idor-request-id-source-js и отсутствием фильтра по req.user.",
    },
    {
        "id": "authz-identity-from-header-js",
        "title": "Идентичность/роль из заголовка запроса (Node)",
        "severity": "medium", "languages": ["js"], "category": "access-control",
        "ignore_case": True,
        "regex": r"\breq(?:uest)?\.(?:headers\s*\[\s*[\x27\"][^\x27\"]*(?:role|user|login|principal|group|scope|tenant|remote[_-]?user|on[_-]?behalf|admin)|get\s*\(\s*[\x27\"][^\x27\"]*(?:role|user|login|principal|scope|tenant))",
        "why": "Роль/идентичность читается из клиентского заголовка. Если перед приложением нет шлюза, режущего такие заголовки, — обход авторизации.",
        "remediation": "Источник идентичности — проверенный JWT/сессия, а не заголовок от клиента; режь identity-заголовки на периметре.",
        "false_positives": "Заголовок ставит доверенный шлюз, клиентский режется.",
        "triage": "Проверь, кто ставит заголовок и санируется ли клиентский.",
    },
    {
        "id": "authz-privilege-param-js",
        "title": "Доверие клиентскому полю роли/привилегии/владельца (Node)",
        "severity": "medium", "languages": ["js"], "category": "access-control",
        "ignore_case": True,
        "regex": r"\breq(?:uest)?\.(?:body|query|params)\.(?:roles?|isadmin|admin|is_admin|grants?|permissions?|scopes?|owner|ownerid|userid|user_id|accountid|tenant|impersonat)\b",
        "why": "Роль/привилегия/владелец берётся из тела или параметров запроса — клиент назначает себе права (вертикальная эскалация) или подменяет владельца.",
        "remediation": "Не принимай роль/владельца от клиента; определяй их на сервере из аутентифицированного принципала.",
        "false_positives": "Чтение для отображения (не для решения о доступе) — менее опасно.",
        "triage": "Проверь, влияет ли это поле на авторизацию/назначение прав.",
    },
    {
        "id": "mass-assignment-js",
        "title": "Mass assignment: модель из req.body целиком (Node)",
        "severity": "low", "languages": ["js"], "category": "access-control",
        "ignore_case": True,
        "regex": r"(?:new\s+[A-Za-z_$][\w$]*\s*\(\s*req\.body|\.(?:create|insert|insertmany|update|updateone|updatemany|findoneandupdate|findbyidandupdate|save)\s*\(\s*req\.body|object\.assign\s*\([^,]+,\s*req\.body)",
        "why": "Объект/документ создаётся или обновляется напрямую из req.body — клиент может задать поля, которые не должен (role/owner/isAdmin).",
        "remediation": "Бери из req.body только разрешённые поля (allowlist/pick); не передавай тело запроса в модель целиком.",
        "false_positives": "Если тело валидируется схемой со strict-allowlist — ок.",
        "triage": "Проверь наличие явного allowlist полей перед записью.",
    },

    # ── инвентаризация URL-эндпоинтов (карта, info) + явный публичный доступ ──
    # «Отсутствие аутентификации» грепом не доказать (это отсутствие конструкции),
    # поэтому даём КАРТУ эндпоинтов (recall, info) для ручной сверки покрытия + явные
    # публичные маркеры (@PermitAll). Spring permitAll/actuator уже покрыты отдельными
    # правилами (spring-permitall-anyrequest, spring-actuator-exposure) — не дублируем.
    {
        "id": "endpoint-jaxrs-path",
        "title": "JAX-RS эндпоинт (@Path) — карта URL",
        "severity": "info", "languages": ["java"], "category": "endpoint-inventory",
        "regex": r"@Path\s*\(\s*[\x27\"]",
        "why": "URL-эндпоинт JAX-RS. Инвентаризация для проверки покрытия аутентификацией/авторизацией.",
        "remediation": "Убедись, что эндпоинт закрыт фильтром/@RolesAllowed или осознанно публичен.",
        "false_positives": "Это карта, не уязвимость (severity info).",
        "triage": "Сверь с покрытием авторизацией: эндпоинт без security-constraint/@RolesAllowed/фильтра + чувствительное действие = доступ без аутентификации.",
    },
    {
        "id": "endpoint-spring-mapping",
        "title": "Spring MVC эндпоинт (@*Mapping) — карта URL",
        "severity": "info", "languages": ["java"], "category": "endpoint-inventory",
        "regex": r"@(?:Request|Get|Post|Put|Delete|Patch)Mapping\b",
        "why": "URL-эндпоинт Spring MVC. Инвентаризация для проверки покрытия аутентификацией.",
        "remediation": "Проверь, что путь защищён в SecurityFilterChain или @PreAuthorize.",
        "false_positives": "Карта, не уязвимость (info).",
        "triage": "Сверь путь с конфигом Spring Security: попадает ли под authenticated()/hasRole(), или открыт permitAll.",
    },
    {
        "id": "endpoint-servlet-mapping",
        "title": "Servlet эндпоинт (@WebServlet / url-pattern) — карта URL",
        "severity": "info", "languages": ["java", "xml"], "category": "endpoint-inventory",
        "regex": r"@WebServlet\b|<\s*url-pattern\s*>",
        "why": "URL-эндпоинт сервлета. Инвентаризация для проверки покрытия security-constraint.",
        "remediation": "Проверь наличие <security-constraint>/<auth-constraint> или фильтра аутентификации для этого пути.",
        "false_positives": "Карта, не уязвимость (info).",
        "triage": "Сверь url-pattern с <security-constraint> в web.xml: путь без auth-constraint = доступ без аутентификации.",
    },
    {
        "id": "endpoint-express-route",
        "title": "HTTP-маршрут (Express/Koa/Fastify) — карта URL",
        "severity": "info", "languages": ["js"], "category": "endpoint-inventory",
        "regex": r"\b[A-Za-z_$][\w$]*\s*\.\s*(?:get|post|put|delete|patch|options|head|all)\s*\(\s*[\x27\"\x60]/",
        "why": "HTTP-маршрут Node. Инвентаризация для проверки наличия middleware аутентификации перед обработчиком.",
        "remediation": "Проверь, что перед обработчиком стоит auth-middleware (requireAuth/passport/ensureLoggedIn) или маршрут осознанно публичен.",
        "false_positives": "Карта, не уязвимость (info). Может совпасть на не-роутерных .get('/...') — отфильтруй вручную.",
        "triage": "Сверь маршрут с цепочкой middleware: есть ли проверка аутентификации до обработчика.",
    },
    {
        "id": "no-auth-permitall-annotation",
        "title": "Аннотация публичного доступа (@PermitAll/@AnonymousAllowed)",
        "severity": "medium", "languages": ["java"], "category": "access-control",
        "regex": r"@(?:PermitAll|AnonymousAllowed|AllowAll|PublicEndpoint|Unsecured)\b",
        "why": "Эндпоинт/класс явно помечен доступным без аутентификации (@PermitAll JSR-250, @AnonymousAllowed Vaadin и т.п.). Если за ним чувствительные данные/действие — доступ без аутентификации.",
        "remediation": "Снимай публичность с чувствительных эндпоинтов; @PermitAll оставляй только для логина/health/static. По умолчанию требуй @RolesAllowed/аутентификацию.",
        "false_positives": "Легитимно для публичных эндпоинтов (логин, health, статика).",
        "triage": "Проверь, что именно открыто: справочник/логин (ок) или чувствительное действие/данные (доступ без аутентификации).",
    },
]

GLOBAL_FLAG_RE = re.compile(r'\(\?[aiLmsux]+\)')


def fix_regex(rx):
    """Нормализует regex: выносит глобальные inline-флаги (?i) в ignore_case.
    Возвращает (regex, ignore_case, error|None)."""
    ic = False
    found = GLOBAL_FLAG_RE.findall(rx)
    if found:
        if any('i' in f for f in found):
            ic = True
        rx = GLOBAL_FLAG_RE.sub('', rx)
    try:
        re.compile(rx, re.IGNORECASE if ic else 0)
        return rx, ic, None
    except re.error as e:
        return rx, ic, str(e)


def load_source():
    # 1) явный источник из argv или дефолтный temp-файл воркфлоу
    if os.path.exists(SRC):
        raw = open(SRC, "r", encoding="utf-8").read()
        wrapper = json.loads(raw)
        data = wrapper["result"] if "result" in wrapper else wrapper
        if isinstance(data, str):
            data = json.loads(data)
        with open(PROVENANCE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)  # провенанс рядом
        return data
    # 2) fallback: ранее сохранённая провенанс-копия (temp мог исчезнуть)
    if os.path.exists(PROVENANCE):
        sys.stderr.write("Источник недоступен, использую %s\n" % PROVENANCE)
        return json.load(open(PROVENANCE, "r", encoding="utf-8"))
    sys.exit("Нет источника правил: ни %s, ни %s" % (SRC, PROVENANCE))


def is_secret_rule(p):
    # ВАЖНО: определяем по id/категории, НЕ по домену (домен «…XXE, SSRF, Secrets…»
    # ложно метил весь домен как секреты → редактировались XXE/десериализация и т.п.).
    rid = (p.get("id") or "").lower()
    cat = (p.get("category") or "").lower()
    id_hints = ("aws-", "asia-", "gcp-", "azure-", "github-token", "gitlab-pat", "slack-",
                "stripe-", "twilio-", "sendgrid-", "firebase-", "google-oauth", "private-key",
                "db-uri-with-password", "jdbc-connection-password", "credentials-in-url",
                "basic-auth-header", "bearer-token", "npmrc-", "hardcoded-password",
                "generic-password", "generic-api-key", "hardcoded-jwt-secret",
                "java-hardcoded-key-iv")
    cat_secret = {"secrets", "secret", "credentials", "credential", "generic-secret",
                  "cloud-aws", "cloud-gcp", "cloud-azure", "payments", "tokens", "vcs-token"}
    if any(h in rid for h in id_hints):
        return True
    return cat in cat_secret


def main():
    data = load_source()
    domains = data.get("domains", [])
    critic = data.get("critic", {})

    rules = []
    for d in domains:
        dom = d.get("domain", "")
        for p in d.get("patterns", []):
            p = dict(p)
            p["_domain"] = dom
            rules.append(p)
    for p in critic.get("additional_patterns", []):
        p = dict(p)
        p["_domain"] = "Critic (gap-fill)"
        rules.append(p)
    # рукописные правила контроля доступа / IDOR (см. EXTRA_RULES)
    for p in EXTRA_RULES:
        p = dict(p)
        p["_domain"] = p.get("_domain", "Access Control (hand-authored)")
        rules.append(p)

    # нормализация + правки
    clean = []
    dropped = []
    for p in rules:
        rid = p.get("id")
        rx, ic, err = fix_regex(p.get("regex", ""))
        if err:
            dropped.append((rid, err))
            continue
        sev = (p.get("severity") or "info").lower()
        langs = [str(l).lower() for l in (p.get("languages") or ["any"])] or ["any"]
        # triage/path-фильтры берём из самого правила-источника, OVERRIDES имеет приоритет
        triage = p.get("triage", "")
        path_inc = p.get("path_include", "")
        path_exc = p.get("path_exclude", "")
        if rid in OVERRIDES:
            ov = OVERRIDES[rid]
            sev = ov.get("severity", sev)
            langs = [l.lower() for l in ov.get("languages", langs)]
            triage = ov.get("triage", triage)
            path_inc = ov.get("path_include", path_inc)
            path_exc = ov.get("path_exclude", path_exc)
            if "regex" in ov:
                rx, ic2, err2 = fix_regex(ov["regex"])
                if not err2:
                    ic = ic2 or ic
                else:
                    dropped.append((rid + " (override)", err2))
        rule = {
            "id": rid,
            "title": p.get("title", rid),
            "severity": sev if sev in SEV_RANK else "info",
            "languages": langs,
            "category": p.get("category", "misc"),
            "regex": rx,
            "ignore_case": bool(p.get("ignore_case", False)) or ic,
            "why": p.get("why", ""),
            "false_positives": p.get("false_positives", ""),
            "remediation": p.get("remediation", ""),
            "secret": is_secret_rule(p),
            "domain": p.get("_domain", ""),
        }
        if triage:
            rule["triage"] = triage
        if path_inc:
            rule["path_include"] = path_inc
        if path_exc:
            rule["path_exclude"] = path_exc
        clean.append(rule)

    # дедуп по (regex, languages) — оставляем правило с более высокой severity
    by_key = {}
    for r in clean:
        key = (r["regex"], tuple(sorted(r["languages"])))
        cur = by_key.get(key)
        if cur is None or SEV_RANK[r["severity"]] > SEV_RANK[cur["severity"]]:
            if cur is not None:
                # сольём языки
                r = dict(r)
                r["languages"] = sorted(set(r["languages"]) | set(cur["languages"]))
            by_key[key] = r
    deduped = list(by_key.values())
    deduped.sort(key=lambda r: (-SEV_RANK[r["severity"]], r["category"], r["id"]))

    ruleset = {
        "version": 1,
        "description": "Static security grep ruleset for Java backend + JavaScript/Node frontend (authorized audit).",
        "rule_count": len(deduped),
        "rules": deduped,
    }
    with open(RULES_OUT, "w", encoding="utf-8") as f:
        json.dump(ruleset, f, ensure_ascii=False, indent=2)

    print("rules written:", len(deduped), "->", RULES_OUT)
    if dropped:
        print("DROPPED (invalid regex):")
        for rid, err in dropped:
            print("   ", rid, "::", err)
    sev = collections.Counter(r["severity"] for r in deduped)
    print("severity:", dict(sev))

    build_methodology(domains, critic, deduped)
    print("methodology written ->", METH_OUT)


def build_methodology(domains, critic, rules):
    # собираем инструменты (дедуп по имени, приоритет — у tooling-домена)
    tools = {}
    tool_order = []
    # сначала специализированный домен инструментов
    ordered_domains = sorted(domains, key=lambda d: 0 if "Tooling" in d.get("domain", "") else 1)
    for d in ordered_domains:
        for t in d.get("tools", []):
            name = t.get("name", "").strip()
            if not name or name in tools:
                continue
            tools[name] = t
            tool_order.append(name)

    # чеклисты ручной экспертизы (дедуп по нормализованному тексту)
    manual = []
    seen = set()
    for d in domains:
        for m in d.get("manual_review", []):
            k = re.sub(r"\s+", " ", m.strip().lower())[:80]
            if k and k not in seen:
                seen.add(k)
                manual.append(m.strip())

    L = []
    A = L.append
    A("# Методология статического анализа безопасности (Java backend + JS/Node frontend)\n")
    A("> Контекст: авторизованный аудит собственного кода в закрытом изолированном тестовом контуре.\n")
    A("> Документ сгенерирован из выверенного набора правил. Дополняйте под свой стек.\n")

    A("\n## 0. Принцип: слои, а не один греп\n")
    A("Греп-сканер (`security_scan.py`) даёт **recall** и работает офлайн без зависимостей — это быстрый триаж и карта подозрительных мест. "
      "Подтверждение эксплуатируемости (source→sink) дают семантические инструменты (Semgrep taint-mode, CodeQL). "
      "Порядок: 1) греп-скан → 2) SAST → 3) сканеры секретов → 4) SCA (зависимости) → 5) ручная экспертиза приоритетных мест.\n")

    A("\n## 1. Инструменты (offline-friendly)\n")
    A("| Инструмент | Назначение | Установка | Команда |")
    A("|---|---|---|---|")
    for name in tool_order:
        t = tools[name]
        purpose = (t.get("purpose", "") or "").replace("\n", " ").replace("|", "\\|")
        install = (t.get("install", "") or "").replace("\n", " ").replace("|", "\\|")
        cmd = (t.get("command", "") or "").replace("\n", " ").replace("|", "\\|")
        A("| **%s** | %s | %s | `%s` |" % (name, purpose, install, cmd))
    A("\n_Примечания по инструментам:_\n")
    for name in tool_order:
        note = tools[name].get("notes", "")
        if note:
            A("- **%s** — %s" % (name, note.replace("\n", " ")))

    pri = critic.get("top_priorities", [])
    if pri:
        A("\n## 2. Порядок проверки по ROI (с чего начинать)\n")
        for p in pri:
            A("- %s" % p.replace("\n", " "))

    A("\n## 3. Запуск греп-сканера\n")
    A("```bash")
    A("# Полный скан каталога с кодом, отчёты в ./sec-report")
    A("python security_scan.py /path/to/code -o sec-report")
    A("")
    A("# Только критичные/высокие находки, с контекстом строк")
    A("python security_scan.py /path/to/code --min-severity high --context 2")
    A("")
    A("# Быстрый триаж через ripgrep (без Python), топ-правила:")
    A("bash quick-scan.sh /path/to/code")
    A("")
    A("# Список всех правил")
    A("python security_scan.py --list-rules")
    A("```")
    A("Отчёты: `findings.json` (машиночитаемый), `report.md` (для людей), `results.sarif` (импорт в IDE/CI). "
      "Подавление по строке: добавьте комментарий `nosec` в строку с заведомо безопасным совпадением.\n")

    A("\n## 4. Чеклист ручной экспертизы\n")
    A("Греп/SAST не находят логические баги и нарушения контроля доступа — это самый частый реальный класс. Проверяйте руками:\n")
    for m in manual:
        A("- [ ] %s" % m)

    miss = critic.get("missing_classes", [])
    if miss:
        A("\n## 5. Дополнительные классы уязвимостей (точечно руками)\n")
        A("Классы, которые греп покрывает слабо или вовсе не покрывает — проверяйте прицельно:\n")
        for m in miss:
            A("- %s" % m.replace("\n", " "))

    A("\n## 6. Триаж и снижение ложных срабатываний\n")
    A("- Для каждой находки трассируйте поток данных от **источника** (request/param/body/header/file/env) до **sink**. Нет недоверенного источника — обычно FP.\n")
    A("- Секреты: отсеивайте плейсхолдеры (`CHANGEME`, `example`, `xxxx`, `placeholder`), ссылки на переменные окружения (`${...}`, `process.env`, `System.getenv`, `@Value`) — сканер делает это автоматически, отключается флагом `--no-secret-fp`.\n")
    A("- Подтверждайте находки высокого риска через Semgrep taint-mode / CodeQL перед эскалацией.\n")
    A("- Сопоставляйте версии библиотек (SCA) с найденными паттернами: уязвимая версия превращает паттерн в готовый эксплойт (например, старый Log4j + `${jndi:`).\n")

    A("\n---\n")
    A("Всего активных правил в `rules.json`: **%d**. Покрытие: Java (SQLi, OS/LDAP/XPath/EL/SpEL/OGNL, SSTI, reflection, десериализация, XXE, SSRF, path traversal, крипто, JWT, Spring Security), JS/Node (DOM XSS, eval, command injection, prototype pollution, NoSQL/SQLi, SSRF, небезопасные cookie/CORS, крипто), секреты и захардкоженные креды.\n" % len(rules))

    with open(METH_OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


if __name__ == "__main__":
    main()
