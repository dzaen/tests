#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
security_scan.py — статический греп-сканер безопасности для Java + JS/Node.

Самодостаточный, только stdlib, работает офлайн (закрытый контур).
Прогоняет набор regex-правил (rules.json) по дереву исходников, помечает
опасные функции/конструкции, инъекции, десериализацию, XXE/SSRF, слабую крипту
и захардкоженные секреты (regex + энтропийный детектор). Отчёты: console / JSON /
Markdown / SARIF.

ВАЖНО: это инструмент ТРИАЖА (recall), а не доказательство уязвимости. Каждую
находку проверяйте вручную и/или через Semgrep taint-mode / CodeQL. См. METHODOLOGY.md.

Примеры:
    python security_scan.py /path/to/code -o sec-report
    python security_scan.py /path/to/code --min-severity high --context 2
    python security_scan.py --list-rules
"""
import argparse
import bisect
import datetime
import sys as _sys  # noqa: E402
try:  # консоль Windows может быть в cp1251 — не падаем на не-ASCII
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
import json
import math
import os
import re
import sys

# ───────────────────────── язык по расширению ─────────────────────────
EXT_LANG = {
    ".java": "java", ".jsp": "java", ".jspx": "java", ".kt": "java",  # kotlin → java-bucket
    ".js": "js", ".jsx": "js", ".mjs": "js", ".cjs": "js",
    ".ts": "js", ".tsx": "js", ".vue": "js", ".svelte": "js",
    ".html": "js", ".htm": "js",
    ".xml": "xml",
    ".properties": "config", ".yml": "config", ".yaml": "config",
    ".json": "config", ".env": "config", ".conf": "config", ".ini": "config",
    ".gradle": "config", ".tf": "config", ".sh": "config", ".bash": "config",
    ".sql": "config", ".pem": "config", ".key": "config", ".cer": "config",
}
# Для какого набора расширений файл считаем "текстом, который сканируем вообще"
TEXT_EXTS = set(EXT_LANG) | {".txt", ".md", ".cfg", ".toml", ".properties"}

DEFAULT_EXCLUDE_DIRS = {
    "node_modules", "bower_components", ".git", ".svn", ".hg", ".idea", ".vscode",
    "dist", "build", "out", "target", ".gradle", ".mvn", "vendor", "__pycache__",
    "coverage", ".next", ".nuxt", ".cache", "venv", ".venv", "site-packages",
    "bin", "obj", ".terraform",
}
DEFAULT_EXCLUDE_GLOBS = ("*.min.js", "*.bundle.js", "*-min.js", "*.map",
                         "*.min.css", "package-lock.json", "yarn.lock")

SEV_RANK = {"info": 1, "low": 2, "medium": 3, "high": 4, "critical": 5}
SEV_ORDER = ["critical", "high", "medium", "low", "info"]

# ── фильтр ложных срабатываний для секретов: ссылки на env/плейсхолдеры ──
SECRET_FP_RE = re.compile(
    r"""(?ix)
    process\.env | import\.meta\.env | os\.getenv | System\.getenv |
    getProperty\s*\( | @Value\s*\( | \$\{[^}]* | \$\([^)]* |
    <%[=@] | \{\{[^}]* |
    change[\-_ ]?me | example\.com | placeholder | dummy | redacted |
    xxxxx | your[-_]?(?:key|token|secret|password) | <[a-z_]+> |
    fake | sample | test[-_]?(?:token|key|secret) | =\s*null | =\s*['\"]['\"]
    """
)

ANSI = {"critical": "\033[1;37;41m", "high": "\033[1;31m", "medium": "\033[1;33m",
        "low": "\033[36m", "info": "\033[2m", "reset": "\033[0m", "bold": "\033[1m",
        "dim": "\033[2m"}


def color(txt, key, enable):
    if not enable:
        return txt
    return ANSI.get(key, "") + txt + ANSI["reset"]


# ───────────────────────── загрузка правил ─────────────────────────
def load_rules(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    raw = data["rules"] if isinstance(data, dict) and "rules" in data else data
    compiled, skipped = [], []
    for r in raw:
        try:
            flags = re.IGNORECASE if r.get("ignore_case") else 0
            r = dict(r)
            # severity из rules.json может быть отредактирован руками — нормализуем,
            # чтобы неизвестное значение не роняло весь скан KeyError на SEV_RANK.
            sev = str(r.get("severity") or "info").lower()
            r["severity"] = sev if sev in SEV_RANK else "info"
            r["_re"] = re.compile(r["regex"], flags)
            r["_langs"] = set(l.lower() for l in r.get("languages", ["any"]))
            r["_pinc"] = re.compile(r["path_include"]) if r.get("path_include") else None
            r["_pexc"] = re.compile(r["path_exclude"]) if r.get("path_exclude") else None
            compiled.append(r)
        except re.error as e:
            skipped.append((r.get("id", "?"), str(e)))
    return compiled, skipped


def rule_path_ok(r, path_fwd):
    """фильтр правила по пути файла: path_exclude/path_include (regex по пути с /)."""
    if r.get("_pexc") and r["_pexc"].search(path_fwd):
        return False
    if r.get("_pinc") and not r["_pinc"].search(path_fwd):
        return False
    return True


# ───────────────────────── обход файлов ─────────────────────────
def matches_glob(name, globs):
    import fnmatch
    return any(fnmatch.fnmatch(name, g) for g in globs)


def is_binary(path, sample=4096):
    try:
        with open(path, "rb") as f:
            chunk = f.read(sample)
        if b"\x00" in chunk:
            return True
        # доля непечатаемых байт
        if chunk:
            text_chars = sum(1 for b in chunk if 9 <= b <= 13 or 32 <= b <= 126 or b >= 128)
            if text_chars / len(chunk) < 0.70:
                return True
    except OSError:
        return True
    return False


def iter_files(target, exclude_dirs, exclude_globs, include_ext, max_bytes, all_ext):
    for root, dirs, files in os.walk(target):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for name in files:
            ext = os.path.splitext(name)[1].lower()
            if include_ext and ext not in include_ext:
                continue
            if not all_ext and ext not in TEXT_EXTS:
                continue
            if matches_glob(name, exclude_globs):
                continue
            full = os.path.join(root, name)
            try:
                if os.path.getsize(full) > max_bytes:
                    continue
            except OSError:
                continue
            if is_binary(full):
                continue
            yield full, ext


def file_langs(ext):
    lang = EXT_LANG.get(ext)
    langs = {"any"}
    if lang:
        langs.add(lang)
    return langs


# ───────────────────────── энтропия ─────────────────────────
def shannon_entropy(s):
    if not s:
        return 0.0
    counts = {}
    for ch in s:
        counts[ch] = counts.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


STRING_LIT_RE = re.compile(r"""(['"`])([^'"`\n]{18,120})\1""")
SECRETISH_CTX_RE = re.compile(
    r"(?i)(secret|passwd|password|pwd|api[_-]?key|apikey|token|access[_-]?key|"
    r"auth|credential|private[_-]?key|signing|client[_-]?secret|salt|bearer)")
B64ISH_RE = re.compile(r"^[A-Za-z0-9+/=_\-]{20,}$")
HEXISH_RE = re.compile(r"^[A-Fa-f0-9]{32,}$")
# файлы, где высокая энтропия — норма, а не секреты: ASN.1/OID, i18n/локализация, минификат
ENTROPY_SKIP_RE = re.compile(
    r"(?i)(oids?\.js$|asn1|/i18n/|/lang/|/locale|messages.*\.(properties|xml)$|"
    r"\b(en|ru|de|fr|es|it|zh|ja)\.(xml|json|properties)$|\.min\.(js|css)$|\.map$)")


def entropy_findings(line, lineno, entropy_min, require_ctx):
    out = []
    has_ctx = bool(SECRETISH_CTX_RE.search(line))
    for m in STRING_LIT_RE.finditer(line):
        val = m.group(2)
        if " " in val or "/" in val and not B64ISH_RE.match(val):
            # пути/URL/предложения — пропускаем, если не похоже на base64/hex
            if not (B64ISH_RE.match(val) or HEXISH_RE.match(val)):
                continue
        ent = shannon_entropy(val)
        if ent < entropy_min:
            continue
        if require_ctx and not has_ctx:
            continue
        sev = "high" if has_ctx else "low"
        out.append((m.start(2), val, ent, sev))
    return out


# ───────────────────────── сканирование файла ─────────────────────────
def line_index(text):
    starts = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            starts.append(i + 1)
    return starts


def lineno_of(starts, offset):
    return bisect.bisect_right(starts, offset)


def redact(s, keep=4):
    s = s.strip()
    if len(s) <= keep * 2:
        return s[:keep] + "…"
    return s[:keep] + "…" + s[-keep:] + " (len=%d)" % len(s)


def scan_file(path, ext, rules, args):
    findings = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError:
        return findings
    starts = line_index(text)
    lines = text.split("\n")
    langs = file_langs(ext)
    path_fwd = path.replace("\\", "/")
    applicable = [r for r in rules if (r["_langs"] & langs) and rule_path_ok(r, path_fwd)]

    def line_at(ln):
        return lines[ln - 1] if 1 <= ln <= len(lines) else ""

    def suppressed(ln):
        return "nosec" in line_at(ln).lower()

    for r in applicable:
        for m in r["_re"].finditer(text):
            ln = lineno_of(starts, m.start())
            if suppressed(ln):
                continue
            line_text = line_at(ln)
            # фильтр FP для секретов
            if r.get("secret") and not args.no_secret_fp and SECRET_FP_RE.search(line_text):
                continue
            full = line_text.strip()
            col0 = m.start() - starts[ln - 1]
            if r.get("secret"):
                mg = m.group(0)
                if "\n" in mg:
                    # многострочный матч (regex с \s* между ключом и значением) — не сплайсим
                    # в одну строку (исказит сниппет/смещение), редактируем целиком.
                    snippet = redact(mg.replace("\n", " "))
                else:
                    # редактируем ТОЛЬКО значение секрета, остальную строку кода оставляем читаемой
                    lead = len(line_text) - len(line_text.lstrip())
                    p0 = max(0, col0 - lead)
                    snippet = full[:p0] + redact(mg) + full[p0 + len(mg):]
            else:
                snippet = full
            snippet = snippet[:300]
            col = col0 + 1
            ctx = []
            if args.context:
                lo = max(1, ln - args.context)
                hi = min(len(lines), ln + args.context)
                ctx = [(i, lines[i - 1][:220]) for i in range(lo, hi + 1)]
            findings.append({
                "file": path, "line": ln, "col": col,
                "rule": r["id"], "title": r["title"], "severity": r["severity"],
                "category": r.get("category", "misc"), "domain": r.get("domain", ""),
                "match": (snippet[:220]),
                "why": r.get("why", ""), "remediation": r.get("remediation", ""),
                "triage": r.get("triage", ""), "false_positives": r.get("false_positives", ""),
                "secret": bool(r.get("secret")),
                "context": ctx,
            })

    # энтропийный детектор секретов (пропускаем заведомо «энтропийные, но не секреты» файлы)
    if args.entropy and ("any" in langs or langs & {"java", "js", "config", "xml"}) \
            and not ENTROPY_SKIP_RE.search(path_fwd):
        for ln, line in enumerate(lines, 1):
            if suppressed(ln):
                continue
            for col0, val, ent, sev in entropy_findings(line, ln, args.entropy_min,
                                                         not args.entropy_all):
                if not args.no_secret_fp and SECRET_FP_RE.search(line):
                    continue
                findings.append({
                    "file": path, "line": ln, "col": col0 + 1,
                    "rule": "high-entropy-string", "title": "High-entropy string (возможный секрет)",
                    "severity": sev, "category": "secrets", "domain": "Entropy",
                    "match": "[" + redact(val) + "] entropy=%.2f" % ent,
                    "why": "Строка с высокой энтропией рядом с ключевыми словами секретов — вероятно захардкоженный ключ/токен.",
                    "remediation": "Вынесите секрет в защищённое хранилище (env/Vault/KMS); удалите из кода и истории VCS.",
                    "triage": "", "false_positives": "Хэши, UUID, минифицированный код, тестовые данные.",
                    "secret": True, "context": [],
                })
    return findings


# ───────────────────────── отчёты ─────────────────────────
def write_json(findings, meta, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "findings": findings}, f, ensure_ascii=False, indent=2)


def write_markdown(findings, meta, path):
    by_sev = {s: [] for s in SEV_ORDER}
    for fi in findings:
        by_sev[fi["severity"]].append(fi)
    L = ["# Отчёт статического анализа безопасности\n",
         "- **Цель:** `%s`" % meta["target"],
         "- **Дата:** %s" % meta["scanned_at"],
         "- **Файлов просканировано:** %d" % meta["files_scanned"],
         "- **Правил активно:** %d" % meta["rules_active"],
         "- **Всего находок:** %d\n" % len(findings)]
    L.append("| Severity | Находок |")
    L.append("|---|---|")
    for s in SEV_ORDER:
        L.append("| %s | %d |" % (s.upper(), len(by_sev[s])))
    L.append("\n> ⚠️ Это результаты триажа (recall). Каждую находку проверяйте вручную / через Semgrep taint-mode / CodeQL.\n")

    for s in SEV_ORDER:
        items = by_sev[s]
        if not items:
            continue
        L.append("\n## %s (%d)\n" % (s.upper(), len(items)))
        # группируем по правилу
        by_rule = {}
        for fi in items:
            by_rule.setdefault(fi["rule"], []).append(fi)
        for rid, group in sorted(by_rule.items(), key=lambda kv: -len(kv[1])):
            g0 = group[0]
            L.append("### `%s` — %s  _(%s, %d)_" % (rid, g0["title"], g0["category"], len(group)))
            if g0["why"]:
                L.append("**Риск:** %s" % g0["why"])
            if g0["remediation"]:
                L.append("**Фикс:** %s" % g0["remediation"])
            if g0.get("triage"):
                L.append("**Триаж:** %s" % g0["triage"])
            L.append("")
            for fi in group[:200]:
                rel = os.path.relpath(fi["file"], meta["target"])
                L.append("- `%s:%d:%d` — `%s`" % (rel, fi["line"], fi["col"], fi["match"]))
            if len(group) > 200:
                L.append("- … ещё %d совпадений" % (len(group) - 200))
            L.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


def write_sarif(findings, meta, path):
    rules_seen, rule_index, sarif_rules = {}, {}, []
    for fi in findings:
        rid = fi["rule"]
        if rid not in rules_seen:
            rule_index[rid] = len(sarif_rules)
            rules_seen[rid] = True
            sarif_rules.append({
                "id": rid,
                "name": fi["title"][:120],
                "shortDescription": {"text": fi["title"]},
                "fullDescription": {"text": (fi["why"] or fi["title"])[:1000]},
                "helpUri": "",
                "properties": {"category": fi["category"], "security-severity":
                               {"critical": "9.5", "high": "8.0", "medium": "5.0",
                                "low": "3.0", "info": "1.0"}.get(fi["severity"], "1.0")},
                "defaultConfiguration": {"level":
                    {"critical": "error", "high": "error", "medium": "warning",
                     "low": "note", "info": "note"}.get(fi["severity"], "note")},
            })
    results = []
    for fi in findings:
        results.append({
            "ruleId": fi["rule"],
            "ruleIndex": rule_index[fi["rule"]],
            "level": {"critical": "error", "high": "error", "medium": "warning",
                      "low": "note", "info": "note"}.get(fi["severity"], "note"),
            "message": {"text": "%s — %s" % (fi["title"], fi["match"])},
            "locations": [{"physicalLocation": {
                "artifactLocation": {"uri": fi["file"].replace("\\", "/")},
                "region": {"startLine": fi["line"], "startColumn": fi["col"],
                           "snippet": {"text": fi["match"]}}}}],
        })
    sarif = {"version": "2.1.0",
             "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
             "runs": [{"tool": {"driver": {"name": "security_scan.py",
                                           "informationUri": "",
                                           "version": "1.0", "rules": sarif_rules}},
                       "results": results}]}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(sarif, f, ensure_ascii=False, indent=2)


def print_console(findings, meta, use_color):
    by_sev = {s: 0 for s in SEV_ORDER}
    by_cat = {}
    by_file = {}
    for fi in findings:
        by_sev[fi["severity"]] += 1
        by_cat[fi["category"]] = by_cat.get(fi["category"], 0) + 1
        by_file[fi["file"]] = by_file.get(fi["file"], 0) + 1
    print()
    print(color("== Security scan summary ==", "bold", use_color))
    print("Target: %s" % meta["target"])
    print("Files scanned: %d   Rules active: %d   Findings: %d"
          % (meta["files_scanned"], meta["rules_active"], len(findings)))
    print()
    for s in SEV_ORDER:
        bar = "#" * min(by_sev[s], 50)
        print("  %-9s %4d %s" % (s.upper(), by_sev[s], color(bar, s, use_color)))
    print()
    print(color("Top categories:", "bold", use_color))
    for cat, n in sorted(by_cat.items(), key=lambda kv: -kv[1])[:12]:
        print("  %-22s %d" % (cat, n))
    print()
    print(color("Top files:", "bold", use_color))
    for fp, n in sorted(by_file.items(), key=lambda kv: -kv[1])[:12]:
        print("  %-60s %d" % (os.path.relpath(fp, meta["target"])[-60:], n))

    # детальный список самых важных
    crit_high = [f for f in findings if f["severity"] in ("critical", "high")]
    crit_high.sort(key=lambda f: (-SEV_RANK[f["severity"]], f["file"], f["line"]))
    show = crit_high[:meta["console_limit"]]
    if show:
        print()
        print(color("== Critical / High (top %d) ==" % len(show), "bold", use_color))
        for fi in show:
            rel = os.path.relpath(fi["file"], meta["target"])
            tag = color("[%s]" % fi["severity"].upper(), fi["severity"], use_color)
            print("%s %s:%d  %s" % (tag, rel, fi["line"], color(fi["rule"], "bold", use_color)))
            print("    %s" % fi["match"])
            for cl, ctext in fi.get("context", []):
                marker = ">>" if cl == fi["line"] else "  "
                print(color("    %s %4d| %s" % (marker, cl, ctext), "dim", use_color))
        if len(crit_high) > len(show):
            print(color("  … ещё %d critical/high (см. report.md / findings.json)"
                        % (len(crit_high) - len(show)), "dim", use_color))


# ───────────────────────── main ─────────────────────────
def main():
    ap = argparse.ArgumentParser(
        description="Статический греп-сканер безопасности (Java + JS/Node), offline.",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("target", nargs="?", help="каталог с исходным кодом")
    ap.add_argument("-r", "--rules", default=None, help="путь к rules.json (по умолчанию рядом со скриптом)")
    ap.add_argument("-o", "--out", default="sec-scan-report", help="каталог для отчётов")
    ap.add_argument("--min-severity", choices=SEV_ORDER, default="info",
                    help="минимальная severity для вывода/отчётов")
    ap.add_argument("--fail-on", choices=SEV_ORDER + ["none"], default="none",
                    help="ненулевой код возврата, если есть находки этой severity и выше (для CI)")
    ap.add_argument("--exclude-dir", action="append", default=[], help="доп. каталог для исключения (повторяемо)")
    ap.add_argument("--exclude-glob", action="append", default=[], help="доп. glob-маска файлов (повторяемо)")
    ap.add_argument("--include-ext", action="append", default=[], help="ограничить расширениями, напр. .java (повторяемо)")
    ap.add_argument("--all-ext", action="store_true", help="сканировать файлы любых расширений (не только известные текстовые)")
    ap.add_argument("--max-bytes", type=int, default=2_000_000, help="пропускать файлы крупнее (байт)")
    ap.add_argument("--context", type=int, default=0, help="строк контекста вокруг находки (console/json)")
    ap.add_argument("--console-limit", type=int, default=40, help="сколько critical/high печатать в консоль")
    ap.add_argument("--no-color", action="store_true", help="отключить цвет")
    ap.add_argument("--no-secret-fp", action="store_true", help="не фильтровать env/плейсхолдеры в секретах")
    ap.add_argument("--entropy", dest="entropy", action="store_true", default=True, help="вкл. энтропийный детектор (по умолчанию вкл.)")
    ap.add_argument("--no-entropy", dest="entropy", action="store_false", help="выкл. энтропийный детектор")
    ap.add_argument("--entropy-min", type=float, default=4.0, help="порог энтропии (бит/символ)")
    ap.add_argument("--entropy-all", action="store_true", help="флагать высокую энтропию даже без ключевых слов рядом")
    ap.add_argument("--list-rules", action="store_true", help="вывести правила и выйти")
    args = ap.parse_args()

    rules_path = args.rules or os.path.join(os.path.dirname(os.path.abspath(__file__)), "rules.json")
    if not os.path.exists(rules_path):
        sys.exit("Не найден rules.json: %s (укажите через -r)" % rules_path)
    rules, skipped = load_rules(rules_path)
    if skipped:
        sys.stderr.write("WARN: пропущено правил из-за ошибок regex: %d\n" % len(skipped))
        for rid, err in skipped:
            sys.stderr.write("   %s: %s\n" % (rid, err))

    use_color = (not args.no_color) and sys.stdout.isatty()

    if args.list_rules:
        rules.sort(key=lambda r: (-SEV_RANK[r["severity"]], r.get("category", "")))
        for r in rules:
            print("%-9s %-26s %-12s %s" % (r["severity"].upper(), ",".join(sorted(r["_langs"])),
                                           r.get("category", ""), r["id"]))
        print("\nВсего правил: %d" % len(rules))
        return

    if not args.target:
        ap.error("укажите каталог с кодом (target) или --list-rules")
    if not os.path.isdir(args.target):
        sys.exit("Не каталог: %s" % args.target)

    target = os.path.abspath(args.target)
    exclude_dirs = DEFAULT_EXCLUDE_DIRS | set(args.exclude_dir)
    exclude_globs = list(DEFAULT_EXCLUDE_GLOBS) + args.exclude_glob
    include_ext = set(e if e.startswith(".") else "." + e for e in args.include_ext)

    findings = []
    files_scanned = 0
    for full, ext in iter_files(target, exclude_dirs, exclude_globs, include_ext,
                                args.max_bytes, args.all_ext):
        files_scanned += 1
        findings.extend(scan_file(full, ext, rules, args))

    # фильтр по severity
    minrank = SEV_RANK[args.min_severity]
    findings = [f for f in findings if SEV_RANK[f["severity"]] >= minrank]
    findings.sort(key=lambda f: (-SEV_RANK[f["severity"]], f["file"], f["line"]))

    meta = {
        "target": target,
        "scanned_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "files_scanned": files_scanned,
        "rules_active": len(rules),
        "console_limit": args.console_limit,
    }

    os.makedirs(args.out, exist_ok=True)
    write_json(findings, meta, os.path.join(args.out, "findings.json"))
    write_markdown(findings, meta, os.path.join(args.out, "report.md"))
    write_sarif(findings, meta, os.path.join(args.out, "results.sarif"))
    print_console(findings, meta, use_color)
    print("\nОтчёты: %s" % os.path.abspath(args.out))
    print("  findings.json · report.md · results.sarif")

    if args.fail_on != "none":
        thr = SEV_RANK[args.fail_on]
        if any(SEV_RANK[f["severity"]] >= thr for f in findings):
            sys.exit(2)


if __name__ == "__main__":
    main()
