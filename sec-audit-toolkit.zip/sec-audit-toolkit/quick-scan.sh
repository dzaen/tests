#!/usr/bin/env bash
# quick-scan.sh — быстрый триаж через ripgrep (без Python/зависимостей).
# Прогоняет ~30 самых ROI-эффективных паттернов (Java + JS/Node) по дереву кода.
# Для полного набора (150 правил) и отчётов используйте security_scan.py.
#
# Использование:  bash quick-scan.sh /path/to/code
# Требует ripgrep (rg) с PCRE2.  Установка: apt/brew/choco install ripgrep
set -o pipefail

TARGET="${1:-.}"
RG="${RG:-rg}"

if ! command -v "$RG" >/dev/null 2>&1; then
  echo "ripgrep (rg) не найден. Установите: apt install ripgrep | brew install ripgrep | choco install ripgrep" >&2
  exit 1
fi

# Общие исключения и флаги
RGFLAGS=(--pcre2 -n --no-heading -S
  -g '!node_modules' -g '!dist' -g '!build' -g '!out' -g '!target'
  -g '!*.min.js' -g '!*.bundle.js' -g '!*.map' -g '!.git')

hr(){ printf '\n\033[1m── %s ──\033[0m\n' "$1"; }
scan(){ # scan "Заголовок" "regex" [доп.флаги rg...]
  local title="$1"; shift
  local pat="$1"; shift
  hr "$title"
  "$RG" "${RGFLAGS[@]}" "$@" -e "$pat" "$TARGET" || true
}

echo "Быстрый security-триаж: $TARGET"
echo "(находки = места для ручной проверки, не доказанные уязвимости)"

# ───── Инъекции / RCE (наивысший приоритет) ─────
scan "SQLi: JDBC/JdbcTemplate/JPA конкатенация" \
  '\.(executeQuery|executeUpdate|execute|createQuery|createNativeQuery|createSQLQuery)\s*\(\s*("[^"]*"\s*\+|[A-Za-z_$][\w$]*\s*\+|String\.format)' -t java
scan "SQLi: MyBatis \${} (только маппер-XML/аннотации)" \
  '\$\{[^}]+\}' -g '*.xml' -t java
scan "OS command injection (Java)" \
  '(Runtime\.getRuntime\(\)\.exec|new\s+ProcessBuilder)\s*\([^)]*(\+|String\.format|\w+\s*\))' -t java
scan "OS command injection (Node)" \
  '\b(exec|execSync|execFile|spawn)\s*\([^;]*(\+|\$\{)' -t js
scan "Code eval (Node/JS)" \
  '\b(eval|new\s+Function|vm\.runInThisContext|vm\.runInNewContext)\s*\(' -t js
scan "SpEL / OGNL / ScriptEngine / Groovy (Java)" \
  '(SpelExpressionParser|ExpressionParser|Ognl\.|ScriptEngineManager|GroovyShell|\.parseExpression\s*\()' -t java

# ───── JNDI / Log4Shell / десериализация ─────
scan "JNDI lookup / Log4Shell" \
  '(InitialContext\(\)\.lookup|Context\.lookup|\$\{jndi:)'
scan "Небезопасная десериализация (Java)" \
  '(ObjectInputStream|\.readObject\s*\(|XMLDecoder|enableDefaultTyping|activateDefaultTyping|@JsonTypeInfo|new\s+Yaml\s*\(\s*\)|\bXStream\b|JSON\.parseObject)' -t java
scan "Небезопасная десериализация (Node)" \
  '(node-serialize|unserialize\s*\(|funcster|load\s*\(.*!!js)' -t js

# ───── XXE / SSRF / path traversal ─────
scan "XXE: парсеры XML без защиты" \
  '(DocumentBuilderFactory|SAXParserFactory|XMLInputFactory|SAXReader|TransformerFactory|XMLReader)' -t java
scan "SSRF: HTTP-клиенты с переменным URL" \
  '(new\s+URL\s*\(|openConnection\s*\(|RestTemplate|WebClient|HttpClient|axios|node-fetch|\bgot\b|require\(.http)'
scan "Path traversal / file API с входными данными" \
  '(new\s+File\s*\(|Paths\.get\s*\(|Files\.(read|write|copy)|fs\.(readFile|createReadStream|sendFile)|res\.sendFile)'

# ───── XSS (frontend) ─────
scan "DOM XSS sinks" \
  '(\.innerHTML\s*=|\.outerHTML\s*=|document\.write|insertAdjacentHTML|dangerouslySetInnerHTML|v-html|bypassSecurityTrust|\.html\s*\()' -t js
scan "Open redirect / location" \
  '(location\s*(\.href)?\s*=|location\.(assign|replace)\s*\(|sendRedirect\s*\(|res\.redirect\s*\(|"redirect:"\s*\+)'
scan "postMessage без проверки origin" \
  '(addEventListener\s*\(\s*["'\'']message|\.postMessage\s*\([^)]*,\s*["'\'']\*)' -t js

# ───── Крипто / TLS / auth ─────
scan "Слабая крипта (DES/ECB/MD5/SHA1/RC4)" \
  '("DES"|"DESede"|/ECB/|"RC4"|getInstance\(\s*"MD5"|getInstance\(\s*"SHA-?1"|createHash\(\s*["'\'']md5|createHash\(\s*["'\'']sha1|createCipher\s*\()'
scan "TLS bypass / trust-all" \
  '(ALLOW_ALL_HOSTNAME_VERIFIER|TrustAllCerts|checkServerTrusted\s*\([^)]*\)\s*\{\s*\}|rejectUnauthorized\s*:\s*false|NODE_TLS_REJECT_UNAUTHORIZED)'
scan "Небезопасный random для секретов" \
  '(new\s+Random\s*\(|Math\.random\s*\()'
scan "JWT: alg none / verify без алгоритмов" \
  '(alg["'\'' ]*[:=]["'\'' ]*none|"none"|jwt\.verify\s*\(|setSigningKey|parseClaimsJws)'
scan "Spring Security ослаблен" \
  '(csrf\(\)\.disable|permitAll\s*\(\s*\)|@CrossOrigin\s*\(\s*"\*"|setAllowedOrigins?\s*\(\s*"\*")' -t java
scan "CORS '*' + credentials (Node)" \
  'origin\s*:\s*["'\'']?\*' -t js

# ───── Секреты ─────
scan "Приватные ключи (PEM)" \
  '-----BEGIN (RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----'
scan "Облачные/сервисные токены" \
  '(AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|AIza[0-9A-Za-z_\-]{35}|ghp_[0-9A-Za-z]{36}|github_pat_[0-9A-Za-z_]{50,}|glpat-[0-9A-Za-z_\-]{20}|xox[baprs]-[0-9A-Za-z-]{10,}|sk_live_[0-9A-Za-z]{20,})'
scan "Захардкоженные пароли/секреты в коде" \
  '(?i)(password|passwd|pwd|secret|api[_-]?key|access[_-]?key|token)\s*[:=]\s*["'\''][^"'\''$\{<][^"'\'']{5,}["'\'']'
scan "Креды в URL подключения" \
  '[a-z]+://[^/\s:]+:[^/\s@]+@'

# ───── Прочие маркеры ─────
scan "Маркеры безопасности в комментариях" \
  '(?i)(TODO|FIXME|HACK|XXX).{0,40}(secur|auth|password|token|vuln|hack|temp|disable)'
scan "Debug / отключённая защита" \
  '(?i)(debug\s*[:=]\s*true|NODE_ENV.{0,10}development|printStackTrace\s*\(|actuator.*exposure.*\*|h2\.console\.enabled\s*=\s*true)'

hr "Готово"
echo "Полный анализ (150 правил, отчёты JSON/MD/SARIF):  python security_scan.py \"$TARGET\" -o sec-report"
