#!/usr/bin/env bash
# build-and-save.sh — СНАРУЖИ (интернет). Собирает образ со всеми сканерами и
# сохраняет его в один tar.gz для переноса в закрытый контур.
#
#   ./build-and-save.sh [--java] [--no-db] [--tag sec-audit-toolkit:1.0]
#
# Результат: ./dist/<tag>.tar.gz + .sha256. Перенесите в контур и: docker load < файл
set -euo pipefail

TAG="sec-audit-toolkit:1.0"
JAVA=false
DB=true
while [ $# -gt 0 ]; do
  case "$1" in
    --java) JAVA=true; shift;;
    --no-db) DB=false; shift;;
    --tag) TAG="$2"; shift 2;;
    -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
    *) echo "неизвестный аргумент: $1" >&2; exit 1;;
  esac
done

ENGINE="$(command -v docker || command -v podman || true)"
[ -z "$ENGINE" ] && { echo "Не найден docker/podman" >&2; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
TOOLKIT="$(cd "$HERE/.." && pwd)"     # контекст сборки = корень тулкита

echo "Сборка $TAG (java=$JAVA, db=$DB) через $(basename "$ENGINE")…"
"$ENGINE" build -f "$HERE/Dockerfile" -t "$TAG" \
  --build-arg INSTALL_JAVA_TOOLS="$JAVA" \
  --build-arg BAKE_DB="$DB" \
  "$TOOLKIT"

mkdir -p "$HERE/dist"
OUT="$HERE/dist/$(echo "$TAG" | tr '/:' '__').tar.gz"
echo "Сохранение в $OUT…"
"$ENGINE" save "$TAG" | gzip > "$OUT"
if command -v sha256sum >/dev/null 2>&1; then sha256sum "$OUT" | tee "$OUT.sha256"; fi

echo ""
echo "Готово: $OUT ($(du -h "$OUT" | cut -f1))"
echo "В контуре:  docker load < \"$(basename "$OUT")\"   (или podman load)"
echo "Запуск:     bash docker/run.sh /path/to/code"
