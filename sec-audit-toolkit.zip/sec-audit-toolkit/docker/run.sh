#!/usr/bin/env bash
# run.sh — В КОНТУРЕ. Запускает аудит в контейнере (docker или podman).
# Код монтируется только на чтение, отчёты пишутся на хост.
#
#   ./run.sh <каталог_с_кодом> [каталог_отчётов] [-- доп.аргументы run-all.sh]
#   IMAGE=sec-audit-toolkit:1.0 ./run.sh /code ./report -- --quick --timeout 1200
#
# Если образ ещё не загружен — сначала: docker load < dist/<file>.tar.gz
set -euo pipefail

IMAGE="${IMAGE:-sec-audit-toolkit:1.0}"
ENGINE="$(command -v docker || command -v podman || true)"
[ -z "$ENGINE" ] && { echo "Не найден docker/podman" >&2; exit 1; }

CODE="${1:-}"; shift || true
[ -z "$CODE" ] && { echo "Использование: $0 <каталог_с_кодом> [каталог_отчётов] [-- доп.аргументы run-all.sh]" >&2; exit 1; }
OUT="./sec-report"; OUT_SET=0; EXTRA=()
while [ $# -gt 0 ]; do
  case "$1" in
    --) shift; EXTRA=("$@"); break;;
    *) if [ "$OUT_SET" = 0 ]; then OUT="$1"; OUT_SET=1; else EXTRA+=("$1"); fi; shift;;
  esac
done

[ -d "$CODE" ] || { echo "Не каталог: $CODE" >&2; exit 1; }
mkdir -p "$OUT"
CODE="$(cd "$CODE" && pwd)"; OUT="$(cd "$OUT" && pwd)"

if ! "$ENGINE" image inspect "$IMAGE" >/dev/null 2>&1; then
  echo "Образ $IMAGE не загружен. Сначала: $ENGINE load < dist/<файл>.tar.gz" >&2
  exit 1
fi

echo "Аудит $CODE → $OUT (образ $IMAGE)…"
"$ENGINE" run --rm \
  --network=none \
  -v "$CODE":/code:ro \
  -v "$OUT":/out \
  "$IMAGE" /code -o /out "${EXTRA[@]+"${EXTRA[@]}"}"

echo "Готово. Отчёты: $OUT (combined.sarif · SUMMARY.md · grep/report.md)"
