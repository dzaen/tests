#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
merge_reports.py — сводит отчёты всех сканеров в один combined.sarif + SUMMARY.md.

Берёт каталог с отчётами (после run-all.sh), собирает все *.sarif в единый SARIF,
считает находки по уровням и инструментам, учитывает не-SARIF выводы (trufflehog json,
npm/yarn audit, osv json). Только stdlib.

Использование: python3 merge_reports.py <report_dir>
"""
import json
import os
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

LEVEL_ORDER = ["error", "warning", "note", "none"]


def find_files(root, exts):
    out = []
    for dp, _, files in os.walk(root):
        for f in files:
            if os.path.splitext(f)[1].lower() in exts:
                out.append(os.path.join(dp, f))
    return out


def load_json(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return json.load(f)
    except Exception as e:
        sys.stderr.write("WARN: не прочитан %s: %s\n" % (path, e))
        return None


def merge_sarif(report_dir):
    runs = []
    per_tool = {}  # tool -> {level: count}
    invalid = []   # пустые/битые SARIF (например, от убитого по таймауту инструмента)
    sarif_files = [p for p in find_files(report_dir, {".sarif"})
                   if os.path.basename(p) != "combined.sarif"]
    for path in sorted(sarif_files):
        if os.path.getsize(path) == 0:
            invalid.append(os.path.basename(path) + " (пустой)"); continue
        data = load_json(path)
        if not data or "runs" not in data:
            invalid.append(os.path.basename(path) + " (битый/обрезанный)"); continue
        for run in data["runs"]:
            runs.append(run)
            tool = run.get("tool", {}).get("driver", {}).get("name", os.path.basename(path))
            tally = per_tool.setdefault(tool, {})
            # карта ruleId -> defaultLevel (для результатов без level)
            rule_levels = {}
            for r in run.get("tool", {}).get("driver", {}).get("rules", []) or []:
                lvl = (r.get("defaultConfiguration") or {}).get("level")
                if lvl:
                    rule_levels[r.get("id")] = lvl
            for res in run.get("results", []) or []:
                lvl = res.get("level") or rule_levels.get(res.get("ruleId")) or "warning"
                tally[lvl] = tally.get(lvl, 0) + 1
    combined = {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": runs,
    }
    with open(os.path.join(report_dir, "combined.sarif"), "w", encoding="utf-8") as f:
        json.dump(combined, f, ensure_ascii=False, indent=2)
    return per_tool, len(sarif_files), invalid


def count_non_sarif(report_dir):
    """Грубый подсчёт находок в не-SARIF отчётах (best-effort)."""
    extras = {}
    # trufflehog: NDJSON или массив
    for name in ("trufflehog.json",):
        p = os.path.join(report_dir, name)
        if os.path.exists(p):
            n = 0
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                txt = f.read().strip()
            if txt.startswith("["):
                d = load_json(p)
                n = len(d) if isinstance(d, list) else 0
            else:
                n = sum(1 for line in txt.splitlines() if line.strip().startswith("{"))
            extras["trufflehog"] = {"findings": n}
    # npm audit
    p = os.path.join(report_dir, "npm-audit.json")
    if os.path.exists(p):
        d = load_json(p) or {}
        meta = (d.get("metadata") or {}).get("vulnerabilities") or {}
        extras["npm-audit"] = meta or {"raw": "see file"}
    # osv json
    p = os.path.join(report_dir, "osv.json")
    if os.path.exists(p):
        d = load_json(p) or {}
        n = sum(len(r.get("packages", [])) for r in d.get("results", []))
        extras["osv-scanner"] = {"vulnerable_packages": n}
    return extras


def main():
    if len(sys.argv) < 2:
        sys.exit("Использование: python3 merge_reports.py <report_dir>")
    report_dir = sys.argv[1]
    if not os.path.isdir(report_dir):
        sys.exit("Не каталог: %s" % report_dir)

    per_tool, n_sarif, invalid = merge_sarif(report_dir)
    extras = count_non_sarif(report_dir)

    L = ["# Сводный отчёт безопасности (агрегация сканеров)\n",
         "- Каталог отчётов: `%s`" % os.path.abspath(report_dir),
         "- SARIF-файлов объединено: %d → `combined.sarif`\n" % n_sarif]

    if per_tool:
        L.append("## Находки по инструментам (SARIF)\n")
        L.append("| Инструмент | error | warning | note | всего |")
        L.append("|---|---|---|---|---|")
        grand = 0
        for tool in sorted(per_tool):
            t = per_tool[tool]
            e, w, no = t.get("error", 0), t.get("warning", 0), t.get("note", 0)
            other = sum(v for k, v in t.items() if k not in ("error", "warning", "note"))
            tot = e + w + no + other
            grand += tot
            L.append("| %s | %d | %d | %d | %d |" % (tool, e, w, no, tot))
        L.append("| **ИТОГО** | | | | **%d** |" % grand)
    else:
        L.append("_SARIF-отчётов не найдено._\n")

    if extras:
        L.append("\n## Прочие отчёты (не-SARIF)\n")
        for tool, info in extras.items():
            L.append("- **%s**: %s" % (tool, json.dumps(info, ensure_ascii=False)))

    if invalid:
        L.append("\n## ⚠️ Пустые/битые отчёты (инструмент упал или прерван по таймауту)\n")
        for x in invalid:
            L.append("- %s" % x)

    L.append("\n## Файлы отчётов\n")
    for f in sorted(os.listdir(report_dir)):
        full = os.path.join(report_dir, f)
        if os.path.isfile(full):
            L.append("- `%s` (%d Б)" % (f, os.path.getsize(full)))
        elif os.path.isdir(full):
            L.append("- `%s/`" % f)

    L.append("\n> Импортируйте `combined.sarif` в VS Code (SARIF Viewer) или CI. "
             "Помните: это триаж — подтверждайте находки вручную.\n")

    with open(os.path.join(report_dir, "SUMMARY.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print("Сводка: %s" % os.path.join(report_dir, "SUMMARY.md"))
    print("Объединённый SARIF: %s" % os.path.join(report_dir, "combined.sarif"))


if __name__ == "__main__":
    main()
