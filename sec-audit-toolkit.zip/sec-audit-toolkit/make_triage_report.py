# -*- coding: utf-8 -*-
"""
make_triage_report.py — сводит combined.sarif в человекочитаемый офлайн-HTML + triaged.json.
Универсальный (не привязан к конкретному проекту): категории выводятся из id правил,
severity берётся из SARIF, уязвимые зависимости — отдельным блоком, дедуп между инструментами,
шум (PMD-качество, vendored/min/test) отсеивается, опц. оверлей перекалибровки по категориям.

Использование:
    python make_triage_report.py <report_dir> [--sarif F] [--calibration F]
                                  [--target DIR] [--title T]
Читает <report_dir>/combined.sarif (или --sarif), пишет <report_dir>/triage-report.html и triaged.json.
"""
import argparse, json, os, re, html, collections, math

SEV_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0, "drop": -1}
SEV_COLOR = {"critical": "#7c1d1d", "high": "#b91c1c", "medium": "#b45309", "low": "#2563eb", "info": "#64748b"}
DEP_TOOLS = {"trivy", "grype", "dependency-check", "osv-scanner", "osv"}

# vendored / минификат / тесты — отсеиваем из security-отчёта
NOISE_PATH_RE = re.compile(r"(?i)(/node_modules/|/bower_components/|/vendor/|/third[_-]?party/|"
                           r"\.min\.(js|css)$|\.bundle\.js$|/dist/|/build/|(^|/)test/|/tests/|"
                           r"__tests__|\.spec\.|\.test\.)")
REDACT_ARTIFACT = re.compile(r"\[[^\]\n]*\(len=\d+\)\]")

# категория по ключевым словам в id правила (универсально для любых инструментов)
CATEGORY_RULES = [
    (r"xxe|xmlinputfactory|documentbuilder|saxparser|disallow-doctype|external-entit", "XXE (парсинг XML)"),
    (r"deserial|readobject|objectinput|xmldecoder|fastjson|snakeyaml|xstream|node-serialize", "Небезопасная десериализация"),
    # контроль доступа / IDOR — ловит наши idor-*/authz-*/mass-assignment-* и CodeQL-сообщения
    # про условный обход «чувствительного» метода от user-controlled значения (ServiceFilter и т.п.)
    (r"\bidor\b|\bauthz\b|broken[\s-]?access|access[\s-]?control|mass-?assign|insecure-?direct|ownership|object-?owner|owner-?check|horizontal|vertical-?priv|priv(?:ilege)?-?esc|\btenant\b|\bbola\b|\bbfla\b|sensitive method|may not be executed|conditional-?bypass", "Контроль доступа / IDOR"),
    (r"\boverflow\b|integer-?overflow|numeric-?(?:overflow|truncation)|arithmetic.*overflow", "Целочисленное переполнение (DoS-edge)"),
    # инвентаризация эндпоинтов (карта URL, info) — для ручной сверки покрытия аутентификацией
    (r"endpoint-|url-?pattern|webservlet|http-?route|express-route|jaxrs-path", "Инвентаризация эндпоинтов"),
    (r"ssti|template.*eval|velocity|freemarker|nunjucks|pug-|ejs-", "SSTI (шаблонизаторы)"),
    (r"mybatis|sql-?inj|sqli|jdbc.*concat|create-?query|createnativequery|hql|jpa-.*concat", "SQL-инъекция"),
    (r"jndi|log4shell|log4j", "JNDI / Log4Shell"),
    (r"command|runtime-?exec|processbuilder|child-?process|os-?command|shelljs", "Command injection"),
    (r"ssrf", "SSRF"),
    (r"jquery.*(html|insecure)|prohibit-jquery", "DOM XSS (jQuery)"),
    (r"xss|innerhtml|outerhtml|document-?write|dangerouslyset|v-html|bypasssecuritytrust|use-escapexml|use-jstl|autoescape|jsp|jstl", "XSS"),
    (r"open-?redirect|sendredirect|src-href|location-assign", "Open redirect"),
    (r"cookie", "Небезопасные cookie"),
    (r"\bcors\b", "CORS"),
    (r"csrf", "CSRF"),
    (r"path-?travers|zip-?slip|file-?api", "Path traversal"),
    (r"prototype-?pollution", "Prototype pollution"),
    (r"redos|unsafe-?regex|dynamic-?regexp", "ReDoS"),
    (r"reflection|forname|newinstance", "Reflection"),
    (r"ldap|xpath|spel|ognl|el-injection|expression", "Инъекции (LDAP/XPath/EL/OGNL)"),
    (r"secret|password|passwd|api-?key|apikey|\btoken\b|private-?key|credential|aws-|gcp-|azure-|github-|gitlab-|slack-|stripe-|twilio-|sendgrid-|hardcoded|bearer|basic-auth|jwt", "Секреты / креды"),
    (r"weak-?(cipher|hash)|md5|sha1|\brc4\b|\bdes\b|ecb|crypto|salt|iv-|insecure-?random|\brandom\b|cipher", "Криптография / случайность"),
    (r"transport|insecure-?transport|plaintext-?http|http-url", "Транспорт (HTTP)"),
    (r"security-?constraint|permitall|actuator|antmatcher|access", "Контроль доступа / конфиг"),
    (r"disabled-?security|debug|tls|jmx|trust-?all|hostname-?verifier|csrf-?disabled", "Опасная конфигурация"),
    (r"resteasy|jax-?rs|mass-?assignment|binder", "REST / биндинг"),
    (r"log(ger)?-?(inj|concat)", "Log injection"),
]

# Дефолтная честная калибровка по категориям: многие правила — presence-check (наличие
# конструкции), а не доказанная уязвимость. Поэтому conf=needs-source + шаг проверки.
# Перекрывается файлом перекалибровки (--calibration), если он задан.
CATEGORY_META = {
    "XXE (парсинг XML)": {"conf": "needs-source", "verify": "Проверь у фабрики хардненинг: disallow-doctype-decl / FEATURE_SECURE_PROCESSING / external-general-entities=false. Если он есть — это FP."},
    "Небезопасная десериализация": {"conf": "needs-source", "verify": "Проверь источник потока (сеть/файл от пользователя?) и наличие gadget-библиотек (commons-collections и т.п.) в зависимостях."},
    "SSTI (шаблонизаторы)": {"conf": "needs-source", "verify": "Проверь, попадает ли пользовательский ввод в ТЕЛО шаблона (как шаблон, а не как данные)."},
    "SQL-инъекция": {"conf": "needs-source", "verify": "Проверь, что значение от пользователя и не параметризовано (? / #{}); ${}/конкатенация = риск."},
    "Command injection": {"conf": "needs-source", "verify": "Проверь источник аргумента команды; есть ли shell."},
    "SSRF": {"conf": "needs-source", "verify": "Контролируется ли URL пользователем; есть ли allowlist хостов."},
    "XSS": {"conf": "needs-source", "verify": "Экранируется ли вывод и приходит ли значение от пользователя (часто это статика/i18n — FP)."},
    "DOM XSS (jQuery)": {"conf": "needs-source", "verify": "Проверь источник HTML-строки (данные пользователя?)."},
    "Open redirect": {"conf": "needs-source", "verify": "Проверь, контролируется ли цель редиректа/ src пользователем."},
    "Небезопасные cookie": {"conf": "likely", "verify": "Сессионная/чувствительная cookie? Добавь Secure + HttpOnly + SameSite."},
    "Path traversal": {"conf": "needs-source", "max_sev": "low", "verify": "Путь от пользователя без нормализации/allowlist?"},
    "Reflection": {"conf": "needs-source", "max_sev": "low", "verify": "Имя класса/метода из пользовательского ввода? Бин/JAXB-маппинг — FP."},
    "Транспорт (HTTP)": {"max_sev": "low", "verify": "Реальный сетевой endpoint или XML namespace/schemaLocation (FP)?"},
    "Опасная конфигурация": {"conf": "needs-source", "verify": "Проверь окружение (prod?) и доступность сервиса извне."},
    "Криптография / случайность": {"conf": "needs-source", "verify": "Используется ли для секретов/токенов/паролей?"},
    "Инъекции (LDAP/XPath/EL/OGNL)": {"conf": "needs-source", "verify": "Проверь источник выражения/фильтра."},
    "Контроль доступа / конфиг": {"conf": "needs-source", "verify": "Проверь, не ослаблен ли доступ (permitAll, ограничение по методам, actuator)."},
    "Контроль доступа / IDOR": {"conf": "needs-review", "verify": "Греп НЕ доказывает IDOR (это семантика владения объектом). Подтверди по коду: (1) идентификатор берётся из запроса (path/query/body/header); (2) по нему идёт прямой доступ к объекту (findById/em.find/Mongoose findOne); (3) НЕТ проверки, что объект принадлежит текущему пользователю (owner==принципал из токена/сессии) или фильтра по владельцу в самом запросе -> горизонтальный IDOR. Для authz-by-header: кто ставит заголовок ролей — доверенный JWT-фильтр/шлюз с затиранием клиентского (FP) или читается сырой клиентский (обход)."},
    "Целочисленное переполнение (DoS-edge)": {"conf": "needs-review", "max_sev": "low", "verify": "В Java нет повреждения памяти — максимум исключение/HTTP 500/DoS. Проверь валидацию диапазона входных чисел (offset/limit) и переполнение при сложении int (offset+limit). Severity не выше low."},
    "Инвентаризация эндпоинтов": {"conf": "needs-review", "max_sev": "info", "verify": "Это КАРТА эндпоинтов (recall), не находка. Сверь каждый с покрытием аутентификацией/авторизацией: <security-constraint> в web.xml, SecurityFilterChain/@PreAuthorize в Spring, @RolesAllowed/фильтр в JAX-RS, auth-middleware в Node. Эндпоинт без покрытия + чувствительное действие = доступ без аутентификации."},
    "REST / биндинг": {"conf": "needs-source", "verify": "Проверь десериализацию тела/привязку полей (mass assignment)."},
    "Prototype pollution": {"conf": "needs-source", "verify": "Источник объекта для merge/set — req.body/JSON пользователя?"},
    "ReDoS": {"conf": "needs-source", "max_sev": "low", "verify": "RegExp из пользовательского ввода?"},
    "Log injection": {"max_sev": "low", "verify": "Пользовательский ввод в лог без санитизации CRLF."},
    "Секреты / креды": {"conf": "confirmed", "verify": "Подтверди, что это значение (а не имя константы/плейсхолдер ${}/env); ротуй секрет."},
}

# PMD-правила качества (наш ruleset errorprone/bestpractices/design) — не security
def is_pmd_quality(tool, rule):
    return tool.lower() == "pmd"


def sev_of(level, secsev):
    try:
        x = float(secsev)
        if not math.isfinite(x):  # "NaN"/"Infinity" -> откат к level-map, а не молчаливый low
            raise ValueError
        return "critical" if x >= 9 else "high" if x >= 7 else "medium" if x >= 4 else "low"
    except (TypeError, ValueError):
        return {"error": "high", "warning": "medium", "note": "low", "none": "info"}.get((level or "").lower(), "medium")


def categorize(rule, msg):
    s = (rule + " " + msg).lower()
    for pat, cat in CATEGORY_RULES:
        if re.search(pat, s):
            return cat
    return "Прочее (требует проверки)"


# ───────── загрузка SARIF ─────────
def load_sarif(path):
    d = json.load(open(path, encoding="utf-8"))
    out = []
    for run in d.get("runs", []):
        drv = run.get("tool", {}).get("driver", {}); tool = drv.get("name", "?")
        rm = {r.get("id"): r for r in (drv.get("rules") or [])}
        for ext in (drv.get("extensions") or []):
            for r in (ext.get("rules") or []):
                rm[r.get("id")] = r
        for r in run.get("results", []) or []:
            rid = r.get("ruleId", "?")
            lvl = r.get("level") or (rm.get(rid, {}).get("defaultConfiguration") or {}).get("level")
            ss = (rm.get(rid, {}).get("properties", {}) or {}).get("security-severity")
            locs = r.get("locations") or []; uri = ""; line = None; snip = ""
            if locs:
                pl = locs[0].get("physicalLocation") or {}
                uri = ((pl.get("artifactLocation") or {}).get("uri")) or ""
                reg = pl.get("region") or {}; line = reg.get("startLine")
                snip = ((reg.get("snippet") or {}).get("text")) or \
                       ((pl.get("contextRegion", {}).get("snippet") or {}).get("text")) or ""
            out.append({"tool": tool, "rule": rid, "level": lvl, "secsev": ss, "file": uri,
                        "line": line, "msg": ((r.get("message") or {}).get("text") or "").strip(),
                        "snippet": snip.strip()})
    seen = set(); u = []
    for f in out:
        k = (f["tool"], f["rule"], f["file"], f["line"], f["msg"][:120])
        if k not in seen:
            seen.add(k); u.append(f)
    return u


def parse_pkg(msg):
    def g(p): m = re.search(p, msg); return m.group(1).strip() if m else ""
    return g(r"Package:\s*([^\n|]+)"), g(r"Installed Version:\s*([^\n|]+)"), g(r"Fixed Version:\s*([^\n|]+)")


def common_prefix(paths):
    paths = [p for p in paths if p]
    if not paths:
        return ""
    pre = os.path.commonprefix(paths)
    return pre[:pre.rfind("/") + 1] if "/" in pre else ""


def load_calibration(path):
    if not path or not os.path.exists(path):
        return {}
    data = json.load(open(path, encoding="utf-8"))
    items = data if isinstance(data, list) else data.get("items", [])
    return {it["category"]: it for it in items}


def clean_detail(c):
    d = (c.get("snippet") or c.get("msg") or "").strip()
    return REDACT_ARTIFACT.sub("…", d)


# ───────── основная обработка ─────────
def process(findings, calib):
    deps = {}; kept = []; excluded = collections.Counter()
    for f in findings:
        tool = f["tool"].lower()
        if tool in DEP_TOOLS:
            cve = f["rule"]
            pkg, inst, fixed = parse_pkg(f["msg"])
            if not pkg:
                pkg = os.path.basename(f["file"]) or f["file"]
            key = (cve, pkg.split(":")[-1])
            sev = sev_of(f["level"], f["secsev"])
            if f["secsev"] is None and tool == "dependency-check":
                sev = "critical" if cve in ("CVE-2014-0114", "CVE-2015-6420", "CVE-2012-0391") else "high"
            rec = deps.get(key)
            if not rec:
                deps[key] = {"cve": cve, "pkg": pkg, "installed": inst, "fixed": fixed,
                             "sev": sev, "engines": {f["tool"]}}
            else:
                rec["engines"].add(f["tool"])
                if not rec["installed"] and inst: rec["installed"] = inst
                if not rec["fixed"] and fixed: rec["fixed"] = fixed
                if SEV_RANK[sev] > SEV_RANK[rec["sev"]]: rec["sev"] = sev
            continue
        if is_pmd_quality(f["tool"], f["rule"]):
            excluded["PMD: качество кода (не security)"] += 1; continue
        if NOISE_PATH_RE.search(f["file"]):
            excluded["vendored / минификат / тесты"] += 1; continue
        cat = categorize(f["rule"], f["msg"])
        sev = sev_of(f["level"], f["secsev"])
        kept.append({**f, "cat": cat, "sev": sev})

    # дедуп кода между инструментами
    bykey = {}
    for k in kept:
        key = (k["cat"], k["file"], k["line"])
        if key in bykey:
            bykey[key]["tools"].add(k["tool"])
            if SEV_RANK[k["sev"]] > SEV_RANK[bykey[key]["sev"]]: bykey[key]["sev"] = k["sev"]
        else:
            k["tools"] = {k["tool"]}; bykey[key] = k
    code = list(bykey.values())
    for c in code:
        m = CATEGORY_META.get(c["cat"], {})
        c["conf"] = m.get("conf") or ("confirmed" if len(c["tools"]) > 1 else "needs-review")
        if m.get("max_sev") and SEV_RANK[c["sev"]] > SEV_RANK[m["max_sev"]]:
            c["sev"] = m["max_sev"]
        if m.get("verify"):
            c["verify"] = m["verify"]

    # оверлей перекалибровки по категориям
    if calib:
        recal = []
        for c in code:
            cb = calib.get(c["cat"])
            if cb:
                if cb.get("verdict") == "false-positive":
                    excluded["перекалибровка → FP: " + c["cat"]] += 1; continue
                c["sev"] = cb.get("severity", c["sev"])
                c["conf"] = cb.get("confidence", c["conf"])
                c["verdict"] = cb.get("verdict", "")
                c["verify"] = cb.get("verify", "")
                c["fp_condition"] = cb.get("fp_condition", "")
                c["reason"] = cb.get("why", "")
            recal.append(c)
        code = recal

    dep_list = sorted(deps.values(), key=lambda r: (-SEV_RANK[r["sev"]], r["pkg"]))
    code.sort(key=lambda r: (-SEV_RANK[r["sev"]], r["cat"], r["file"], r["line"] or 0))
    return dep_list, code, excluded


# ───────── HTML ─────────
def esc(x): return html.escape(str(x) if x is not None else "")

def badge(sev):
    return '<span style="background:%s;color:#fff;padding:1px 7px;border-radius:4px;font-size:11px;font-weight:600">%s</span>' % (
        SEV_COLOR.get(sev, "#555"), sev.upper())

def render_html(deps, code, excluded, total, title, prefix, out_html):
    import datetime
    P = []; A = P.append
    kept_sev = collections.Counter(c["sev"] for c in code)
    dep_sevc = collections.Counter(d["sev"] for d in deps)
    n_excl = sum(excluded.values())
    A("""<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>%s</title><style>
*{box-sizing:border-box}body{font:14px/1.5 -apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:0;color:#1f2937;background:#f8fafc}
.wrap{max-width:1100px;margin:0 auto;padding:24px}h1{font-size:24px;margin:0 0 4px}
h2{font-size:19px;margin:28px 0 10px;padding-bottom:6px;border-bottom:2px solid #e5e7eb}
.muted{color:#6b7280;font-size:13px}.card{background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:12px 14px;margin:10px 0}
table{border-collapse:collapse;width:100%%;font-size:13px;background:#fff}th,td{border:1px solid #e5e7eb;padding:6px 8px;text-align:left;vertical-align:top}
th{background:#f1f5f9}code{background:#f1f5f9;padding:1px 5px;border-radius:4px;font-size:12px;word-break:break-all}
.stat{display:inline-block;min-width:92px;padding:10px 14px;margin:4px 6px 4px 0;border-radius:8px;color:#fff;text-align:center}
.snip{font-family:ui-monospace,Consolas,monospace;font-size:12px;background:#0f172a;color:#e2e8f0;padding:6px 8px;border-radius:5px;white-space:pre-wrap;word-break:break-all;margin-top:4px}
details{margin:6px 0}summary{cursor:pointer;font-weight:600}.file{color:#374151;font-size:12px}
.conf-confirmed{color:#15803d;font-weight:600}.conf-likely{color:#b45309}.conf-needs-review,.conf-needs-source{color:#6b7280}.conf-low{color:#9ca3af}
</style></head><body><div class="wrap">""" % esc(title))
    A("<h1>%s</h1>" % esc(title))
    A('<div class="muted">Сгенерировано %s · находок на входе: %d%s</div>'
      % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), total, (" · база путей: <code>%s</code>" % esc(prefix)) if prefix else ""))
    A("<h2>Сводка</h2>")
    for s in ("critical", "high", "medium", "low"):
        A('<span class="stat" style="background:%s">%s<br><b style="font-size:18px">%d</b></span>' % (SEV_COLOR[s], s.upper(), kept_sev.get(s, 0)))
    A('<span class="stat" style="background:#334155">ЗАВИСИМОСТИ<br><b style="font-size:18px">%d</b></span>' % len(deps))
    A('<span class="stat" style="background:#94a3b8">отсеяно шума<br><b style="font-size:18px">%d</b></span>' % n_excl)
    A('<div class="card muted">⚠️ Триаж (recall): подтверждай находки вручную (source→sink). '
      '<b>confirmed</b> — найдено ≥1 инструментом/со сниппетом; <b>needs-review/needs-source</b> — требует проверки источника данных.</div>')

    # зависимости
    A("<h2>1. Уязвимые зависимости (%d)%s</h2>" % (len(deps),
      (" — " + ", ".join("%s:%d" % (k.upper(), v) for k, v in sorted(dep_sevc.items(), key=lambda x:-SEV_RANK[x[0]]))) if deps else ""))
    if deps:
        A('<div class="muted">Устаревшие библиотеки с известными CVE — обновить до версии из колонки «Исправлено в».</div>')
        A("<table><tr><th>Severity</th><th>CVE</th><th>Пакет</th><th>Уст.</th><th>Исправлено в</th><th>Движок</th></tr>")
        for d in deps:
            A("<tr><td>%s</td><td><code>%s</code></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>" % (
                badge(d["sev"]), esc(d["cve"]), esc(d["pkg"]), esc(d["installed"] or "—"), esc(d["fixed"] or "—"),
                esc(", ".join(sorted(d["engines"])))))
        A("</table>")
    else:
        A('<div class="muted">Нет (SCA-инструменты не запускались или зависимостей не найдено).</div>')

    # код
    A("<h2>2. Находки в коде (%d)%s</h2>" % (len(code),
      (" — " + ", ".join("%s:%d" % (k.upper(), v) for k, v in sorted(kept_sev.items(), key=lambda x:-SEV_RANK[x[0]]))) if code else ""))
    bycat = collections.OrderedDict()
    for c in code: bycat.setdefault(c["cat"], []).append(c)
    for cat in sorted(bycat, key=lambda k: -max(SEV_RANK[x["sev"]] for x in bycat[k])):
        items = bycat[cat]; maxsev = max(items, key=lambda x: SEV_RANK[x["sev"]])["sev"]; g0 = items[0]
        A('<details %s><summary>%s %s <span class="muted">(%d)</span></summary>' % (
            "open" if SEV_RANK[maxsev] >= 3 else "", badge(maxsev), esc(cat), len(items)))
        if g0.get("reason"): A('<div class="muted" style="margin:6px 0">%s</div>' % esc(g0["reason"]))
        if g0.get("verdict"): A('<div class="muted" style="margin:4px 0"><b>Вердикт:</b> %s</div>' % esc(g0["verdict"]))
        if g0.get("verify"): A('<div class="card" style="margin:6px 0"><b>Как проверить:</b> %s</div>' % esc(g0["verify"]))
        if g0.get("fp_condition"): A('<div class="muted" style="margin:4px 0"><b>Когда это FP:</b> %s</div>' % esc(g0["fp_condition"]))
        A("<table><tr><th>Sev</th><th>Файл:строка</th><th>Деталь</th><th>Увер.</th><th>Инстр.</th></tr>")
        for c in items[:400]:
            fileshort = c["file"][len(prefix):] if prefix and c["file"].startswith(prefix) else c["file"]
            A('<tr><td>%s</td><td class="file"><code>%s:%s</code></td><td><div class="snip">%s</div></td>'
              '<td class="conf-%s">%s</td><td>%s</td></tr>' % (
                badge(c["sev"]), esc(fileshort), esc(c["line"]), esc(clean_detail(c)[:400]),
                c.get("conf", ""), c.get("conf", ""), esc(", ".join(sorted(c["tools"])))))
        if len(items) > 400: A('<tr><td colspan=5>… ещё %d</td></tr>' % (len(items) - 400))
        A("</table></details>")

    # исключено
    A("<h2>3. Исключено как шум (%d)</h2>" % n_excl)
    A('<div class="muted">Прозрачно: что и почему отброшено.</div>')
    A("<table><tr><th>Кол-во</th><th>Причина</th></tr>")
    for reason, n in excluded.most_common():
        A("<tr><td>%d</td><td>%s</td></tr>" % (n, esc(reason)))
    A("</table>")
    A('<h2>Как читать</h2><div class="card">Сначала — зависимости (critical/high) и блоки десериализации/инъекций/секретов. '
      'Для needs-review/needs-source трассируй источник данных до sink. combined.sarif открывается в VS Code (SARIF Viewer).</div>')
    A("</div></body></html>")
    open(out_html, "w", encoding="utf-8").write("".join(P))


def main():
    ap = argparse.ArgumentParser(description="SARIF → офлайн-HTML триаж-отчёт")
    ap.add_argument("report_dir", help="каталог с combined.sarif (туда же пишутся отчёты)")
    ap.add_argument("--sarif", default=None, help="путь к SARIF (по умолчанию <report_dir>/combined.sarif)")
    ap.add_argument("--calibration", default=None, help="JSON перекалибровки по категориям (опц.)")
    ap.add_argument("--target", default=None, help="корень сканированного кода (для укорочения путей)")
    ap.add_argument("--title", default="Отчёт триажа статического анализа безопасности")
    args = ap.parse_args()

    sarif = args.sarif or os.path.join(args.report_dir, "combined.sarif")
    if not os.path.exists(sarif):
        import sys; sys.exit("Не найден SARIF: %s" % sarif)
    calib_path = args.calibration or (os.path.join(args.report_dir, "_calibration.json")
                                      if os.path.exists(os.path.join(args.report_dir, "_calibration.json")) else None)

    findings = load_sarif(sarif)
    calib = load_calibration(calib_path)
    deps, code, excluded = process(findings, calib)

    prefix = (args.target.replace("\\", "/").rstrip("/") + "/") if args.target else common_prefix([f["file"] for f in findings])
    out_html = os.path.join(args.report_dir, "triage-report.html")
    out_json = os.path.join(args.report_dir, "triaged.json")
    json.dump({"dependencies": [{**d, "engines": sorted(d["engines"])} for d in deps],
               "code": [{**c, "tools": sorted(c.get("tools", []))} for c in code],
               "excluded": dict(excluded)}, open(out_json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    render_html(deps, code, excluded, len(findings), args.title, prefix, out_html)

    ks = collections.Counter(c["sev"] for c in code); ds = collections.Counter(d["sev"] for d in deps)
    print("Зависимости:", len(deps), dict(ds))
    print("Код:", len(code), dict(ks))
    print("Отсеяно:", sum(excluded.values()))
    print("HTML:", out_html)
    if calib_path:
        print("Перекалибровка:", calib_path)


if __name__ == "__main__":
    main()
