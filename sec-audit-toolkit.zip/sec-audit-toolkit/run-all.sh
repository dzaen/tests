#!/usr/bin/env bash
# run-all.sh — оркестратор аудита: запускает ВСЕ доступные сканеры по дереву кода,
# складывает отчёты в один каталог, сводит SARIF (combined.sarif + SUMMARY.md).
#
# Особенности:
#  - автодетект: инструмент запускается только если найден; иначе [SKIP] с пояснением;
#  - у каждого инструмента ТАЙМАУТ (по умолчанию 900с) — ничего не виснет навсегда;
#  - УСПЕХ определяется по факту созданного отчёта, а не по коду возврата
#    (коды "найдены проблемы" не считаются ошибкой, а падение/краш не маскируется под OK);
#  - прогресс виден на экране + дублируется в логи $OUT/logs/<tool>.log;
#  - всё в ОФЛАЙН-режиме (без сетевых обновлений БД/правил/телеметрии).
#  - security_scan.py запускается всегда (ничего не требует).
#
# Использование:
#   ./run-all.sh <каталог_с_кодом> [-o отчёты] [--codeql] [--java-built] [--quick]
#                [--grype] [--timeout СЕК] [--trivy-misconfig]
#   --codeql      запустить CodeQL (Java/JS, buildless — СБОРКА НЕ НУЖНА; тяжёлый)
#   --java-built  запустить SpotBugs (нужен скомпилированный байткод проекта)
#
# Рядом лежащий sectools/env.sh (после install-tools.sh) подхватывается автоматически.
set -o pipefail

# ───────── аргументы ─────────
TARGET=""; OUT=""; JAVA_BUILT=0; RUN_QUICK=0; TRIVY_MISCONFIG=0; RUN_GRYPE=0; RUN_CODEQL=0; RUN_ESLINT=0
TOOL_TIMEOUT="${TOOL_TIMEOUT:-900}"
while [ $# -gt 0 ]; do
  case "$1" in
    -o|--out) OUT="$2"; shift 2;;
    --java-built) JAVA_BUILT=1; shift;;
    --codeql) RUN_CODEQL=1; shift;;
    --eslint) RUN_ESLINT=1; shift;;
    --quick) RUN_QUICK=1; shift;;
    --grype) RUN_GRYPE=1; shift;;
    --timeout) TOOL_TIMEOUT="$2"; shift 2;;
    --trivy-misconfig) TRIVY_MISCONFIG=1; shift;;
    -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
    *) TARGET="$1"; shift;;
  esac
done
[ -z "$TARGET" ] && { echo "Укажите каталог с кодом. Справка: $0 --help" >&2; exit 1; }
[ -d "$TARGET" ] || { echo "Не каталог: $TARGET" >&2; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="$(cd "$TARGET" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S 2>/dev/null || echo run)"
[ -z "$OUT" ] && OUT="$HERE/report-$STAMP"
LOG="$OUT/logs"; mkdir -p "$OUT" "$LOG"

# Подхватить окружение установленного набора инструментов
for envf in "$HERE/sectools/env.sh" "${SECTOOLS_ENV:-}"; do
  if [ -n "$envf" ] && [ -f "$envf" ]; then . "$envf"; echo "env: подхвачен $envf"; fi
done

PYTHON="${PYTHON:-python3}"; command -v "$PYTHON" >/dev/null 2>&1 || PYTHON=python
TIMEOUT_BIN="$(command -v timeout || true)"

# UTF-8 локаль для Java-инструментов: иначе кириллические имена файлов (в т.ч. внутри zip)
# валят Dependency-Check/PMD/CodeQL с InvalidPathException: "unmappable characters".
# Решает именно LC_ALL/LANG (читается JVM при старте); -Dfile.encoding — дополнение.
case "${LC_ALL:-${LANG:-}}" in
  *UTF-8|*utf-8|*UTF8|*utf8) : ;;
  *) export LANG=C.UTF-8 LC_ALL=C.UTF-8 ;;
esac
export JAVA_TOOL_OPTIONS="-Dfile.encoding=UTF-8 ${JAVA_TOOL_OPTIONS:-}"

echo "=================================================="
echo " Security run-all"
echo " Цель:     $TARGET"
echo " Отчёты:   $OUT"
echo " Таймаут:  ${TOOL_TIMEOUT}s на инструмент$([ -z "$TIMEOUT_BIN" ] && echo '  (!) утилита timeout не найдена — без ограничения')"
echo "=================================================="

declare -a RAN SKIPPED FAILED
have(){ command -v "$1" >/dev/null 2>&1; }
section(){ printf '\n\033[1m── %s ──\033[0m\n' "$1"; }
skip(){ echo "  [SKIP] $1 — не найден в PATH или нет данных (см. install/fetch-tools.sh)"; SKIPPED+=("$1"); }
# БЕЗ --preserve-status: timeout вернёт 124 при срабатывании (а не 143), и таймаут распознаётся.
tmo(){ if [ -n "$TIMEOUT_BIN" ]; then "$TIMEOUT_BIN" --kill-after=30s "$TOOL_TIMEOUT" "$@"; else "$@"; fi; }
# runlog <logname> <cmd...> : запуск с таймаутом; stdout+stderr на экран и в лог; возвращает код инструмента.
runlog(){ local n="$1"; shift; tmo "$@" 2>&1 | tee "$LOG/$n.log"; return "${PIPESTATUS[0]}"; }

# run_tool <name> <available 0/1> <func> [expected_report_file]
# УСПЕХ = код 0 ИЛИ инструмент создал непустой отчёт (так коды "найдены проблемы" не считаются
# ошибкой, а краш/неверный флаг — наоборот, не маскируются под OK, т.к. отчёта не будет).
run_tool(){
  local name="$1" avail="$2" func="$3" out="${4:-}"
  section "$name"
  if [ "$avail" != 1 ]; then skip "$name"; return; fi
  local t0=$SECONDS rc=0
  "$func" || rc=$?
  if [ "$rc" = 124 ] || [ "$rc" = 125 ] || [ "$rc" = 137 ] || [ "$rc" = 143 ]; then
    echo "  [TIMEOUT] $name (> ${TOOL_TIMEOUT}s) — прерван, иду дальше"; FAILED+=("$name:timeout"); return
  fi
  if [ "$rc" = 0 ] || { [ -n "$out" ] && [ -s "$out" ]; }; then
    echo "  [OK] $name ($((SECONDS - t0))s)"; RAN+=("$name")
  else
    echo "  [WARN] $name: код $rc, отчёт не создан — см. лог $LOG/ — иду дальше"; FAILED+=("$name:rc$rc")
  fi
}

# ───────── 1. Питон греп-сканер (всегда) ─────────
section "security_scan.py (греп-правила + секреты)"
if [ -f "$HERE/security_scan.py" ]; then
  "$PYTHON" "$HERE/security_scan.py" "$TARGET" -o "$OUT/grep" --no-color 2>&1 | tee "$LOG/security_scan.log"
  RAN+=("security_scan.py")
else
  skip "security_scan.py"
fi

# ───────── 1b. quick-scan.sh (опц.) ─────────
if [ "$RUN_QUICK" = 1 ] && [ -f "$HERE/quick-scan.sh" ] && have rg; then
  section "quick-scan.sh (ripgrep)"
  bash "$HERE/quick-scan.sh" "$TARGET" > "$OUT/quick-scan.txt" 2>&1 || true
  echo "  -> $OUT/quick-scan.txt"; RAN+=("quick-scan.sh")
fi

# ───────── 2. Semgrep (SAST, офлайн по локальным правилам) ─────────
sm_check=0; sm_args=()
if have semgrep; then
  if [ -n "${SEMGREP_RULES:-}" ] && [ -d "${SEMGREP_RULES:-/nonexistent}" ]; then
    for sub in java javascript typescript owasp-top-ten secrets jwt; do
      [ -d "$SEMGREP_RULES/$sub" ] && sm_args+=(--config "$SEMGREP_RULES/$sub")
    done
    [ ${#sm_args[@]} -eq 0 ] && sm_args+=(--config "$SEMGREP_RULES")
    sm_check=1
  else
    section "Semgrep"; echo "  [SKIP] semgrep есть, но SEMGREP_RULES не задан/нет каталога — пропуск (чтобы не лезть в сеть)"; SKIPPED+=("Semgrep")
  fi
else
  section "Semgrep"; skip "Semgrep"
fi
# Успех проверяется по наличию semgrep.sarif: краш на импорте (нет setuptools/pkg_resources в venv)
# теперь честно помечается [WARN], а не маскируется под OK.
step_semgrep(){
  SEMGREP_SEND_METRICS=off SEMGREP_ENABLE_VERSION_CHECK=0 \
  runlog semgrep semgrep scan --metrics=off --disable-version-check \
    --timeout 180 --timeout-threshold 3 \
    --exclude node_modules --exclude .git --exclude '*.min.js' \
    "${sm_args[@]}" --sarif --output "$OUT/semgrep.sarif" "$TARGET"
}
[ "$sm_check" = 1 ] && run_tool "Semgrep" 1 step_semgrep "$OUT/semgrep.sarif"

# ───────── 3. gitleaks (секреты, офлайн) ─────────
# В 8.19+ команда сканирования каталога — `gitleaks dir` (старая `detect` устарела).
step_gitleaks(){
  runlog gitleaks gitleaks dir "$TARGET" --redact=100 --exit-code 0 \
    --report-format sarif --report-path "$OUT/gitleaks.sarif"
  if grep -qiE 'unknown command|unknown flag' "$LOG/gitleaks.log" 2>/dev/null; then  # старые версии (<8.19)
    runlog gitleaks gitleaks detect --no-git --source "$TARGET" --redact --exit-code 0 \
      --report-format sarif --report-path "$OUT/gitleaks.sarif"
  fi
}
run_tool "gitleaks" "$(have gitleaks && echo 1 || echo 0)" step_gitleaks "$OUT/gitleaks.sarif"

# ───────── 4. trufflehog (секреты, без верификации=офлайн) ─────────
step_trufflehog(){
  tmo trufflehog filesystem "$TARGET" --no-verification --json > "$OUT/trufflehog.json" 2> "$LOG/trufflehog.log"
  local rc=$?
  local n; n="$(grep -c '"SourceMetadata"' "$OUT/trufflehog.json" 2>/dev/null || true)"; [ -z "$n" ] && n=0
  echo "  находок: $n (лог: $LOG/trufflehog.log)"; return $rc
}
run_tool "trufflehog" "$(have trufflehog && echo 1 || echo 0)" step_trufflehog

# ───────── 5. Trivy (SCA + секреты, офлайн) ─────────
step_trivy(){
  local scanners="vuln,secret"; [ "$TRIVY_MISCONFIG" = 1 ] && scanners="vuln,secret,misconfig"
  # флаг называется --skip-version-check (НЕ --skip-check-update — такого нет).
  runlog trivy trivy fs --offline-scan --skip-db-update --skip-java-db-update --skip-version-check \
    ${TRIVY_CACHE_DIR:+--cache-dir "$TRIVY_CACHE_DIR"} --no-progress --timeout 10m \
    --scanners "$scanners" --format sarif --output "$OUT/trivy.sarif" "$TARGET"
}
run_tool "Trivy" "$(have trivy && echo 1 || echo 0)" step_trivy "$OUT/trivy.sarif"

# ───────── 6. Grype (SCA, офлайн; opt-in — медленный, дублирует Trivy/OSV) ─────────
step_grype(){
  # -o sarif=FILE (форма --file устарела). Требует GRYPE_DB_CACHE_DIR (env.sh/Docker).
  GRYPE_DB_AUTO_UPDATE=false GRYPE_CHECK_FOR_APP_UPDATE=false GRYPE_DB_VALIDATE_AGE=false \
    runlog grype grype "dir:$TARGET" -o "sarif=$OUT/grype.sarif" \
      --exclude './**/node_modules/**' --exclude './**/.git/**'
}
if [ "$RUN_GRYPE" = 1 ]; then
  run_tool "Grype" "$(have grype && echo 1 || echo 0)" step_grype "$OUT/grype.sarif"
else
  section "Grype"; echo "  [SKIP] выключен по умолчанию (медленный; дублирует Trivy/OSV). Включить: --grype"; SKIPPED+=("Grype")
fi

# ───────── 7. OSV-Scanner (SCA, офлайн; нужна локальная БД) ─────────
osv_a=0
if have osv-scanner; then
  if [ -n "${OSV_OFFLINE_DB:-}" ] && [ -d "${OSV_OFFLINE_DB:-/x}" ]; then osv_a=1
  else section "OSV-Scanner"; echo "  [SKIP] osv-scanner есть, но нет оффлайн-БД (OSV_OFFLINE_DB). Соберите: fetch-tools.sh PROJECT_DIR=..."; SKIPPED+=("OSV-Scanner"); fi
else
  section "OSV-Scanner"; skip "OSV-Scanner"
fi
step_osv(){
  # --no-ignore: не обрабатывать .gitignore (каталог не git-репо → osv сыпет "Failed to resolve gitignore"
  # на каждый путь). Для security-скана корректно: ничего не должно прятаться через .gitignore.
  # v1.9.1: только эти флаги (НЕ 'scan source' — это v2). БД: $OSV_OFFLINE_DB/osv-scanner/<eco>/all.zip
  runlog osv osv-scanner --experimental-offline --experimental-local-db-path "$OSV_OFFLINE_DB" \
    --no-ignore --format sarif --output "$OUT/osv.sarif" -r "$TARGET"
  local rc=$?
  # коды v1.9.1: 0=чисто, 1=найдены уязвимости, 128=нет источников пакетов
  case $rc in 1) rc=0;; 128) echo "  (lock-файлов/зависимостей не найдено)"; rc=0;; esac
  return $rc
}
[ "$osv_a" = 1 ] && run_tool "OSV-Scanner" 1 step_osv "$OUT/osv.sarif"

# ───────── 8. OWASP Dependency-Check (Java SCA, офлайн NVD) ─────────
step_depcheck(){
  # Предупреждаем, если база NVD не задана/пуста — иначе DepCheck падает с "No documents exist".
  if [ -z "${DEPENDENCY_CHECK_DATA:-}" ]; then
    echo "  (!) DEPENDENCY_CHECK_DATA не задан — DepCheck ищет базу NVD в каталоге по умолчанию (вероятно пуст в офлайне)"
  elif [ ! -e "$DEPENDENCY_CHECK_DATA/odc.mv.db" ] && [ -z "$(ls -A "$DEPENDENCY_CHECK_DATA" 2>/dev/null)" ]; then
    echo "  (!) Каталог NVD пуст: $DEPENDENCY_CHECK_DATA — нужен dependency-check --updateonly (см. подсказку ниже)"
  fi
  # ОФЛАЙН: отключаем сетевые анализаторы. ВНИМАНИЕ: --disableNexus/--disableArtifactory НЕ существуют
  # в 11.x (эти анализаторы и так выключены по умолчанию) — их добавление валит запуск.
  runlog depcheck dependency-check.sh --project audit --scan "$TARGET" --noupdate --failOnCVSS 11 \
    --disableCentral --disableOssIndex --disableNodeAudit --disableAssembly --disableRetireJS \
    --disableKnownExploited --disableHostedSuppressions \
    ${DEPENDENCY_CHECK_DATA:+--data "$DEPENDENCY_CHECK_DATA"} \
    --format SARIF --format HTML --out "$OUT/depcheck"
  local rc=$?
  [ -f "$OUT/depcheck/dependency-check-report.sarif" ] && cp "$OUT/depcheck/dependency-check-report.sarif" "$OUT/depcheck.sarif"
  if grep -qiE "No documents exist|Unable to continue dependency-check" "$LOG/depcheck.log" 2>/dev/null; then
    echo "  | ПРИЧИНА: база NVD пуста. На машине с интернетом (свой ключ NVD):"
    echo "  |   dependency-check.sh --updateonly --data <DIR> --nvdApiKey \$NVD_API_KEY"
    echo "  | перенеси <DIR> в контур, затем: export DEPENDENCY_CHECK_DATA=<DIR> (или через sectools/env.sh)."
    echo "  | Это вернёт CVE по JAR'ам (Struts/commons-collections/Jetty и т.п.)."
  fi
  return $rc
}
run_tool "OWASP Dependency-Check" "$(have dependency-check.sh && echo 1 || echo 0)" step_depcheck "$OUT/depcheck.sarif"

# ───────── 9. PMD (Java AST-линт) ─────────
# В PMD 7 НЕТ category/java/security.xml — ссылка на него валит запуск (ruleset not found).
step_pmd(){ runlog pmd pmd check -d "$TARGET" \
  -R category/java/errorprone.xml,category/java/bestpractices.xml,category/java/design.xml \
  -f sarif -r "$OUT/pmd.sarif" --no-fail-on-violation; }
run_tool "PMD" "$(have pmd && echo 1 || echo 0)" step_pmd "$OUT/pmd.sarif"

# ───────── 10. njsscan (Node SAST) ─────────
step_njsscan(){ runlog njsscan njsscan --sarif -o "$OUT/njsscan.sarif" "$TARGET"; }
run_tool "njsscan" "$(have njsscan && echo 1 || echo 0)" step_njsscan "$OUT/njsscan.sarif"

# ───────── 11. ESLint security (Node) ─────────
# ESLINT_USE_FLAT_CONFIG=false заставляет ESLint 8 и 9 читать legacy .eslintrc (на 9 --no-eslintrc/--ext убраны).
# .ts/.tsx убраны: без @typescript-eslint/parser дают fatal parse error. Только .js/.jsx.
# ESLint — ОПЦИОНАЛЬНО (--eslint) и только при установленных плагинах. Нужен eslint@8
# (6.x EOL и багует на путях). JS и так покрывают Semgrep + njsscan — ESLint лишь дополнение.
es=0
if [ "$RUN_ESLINT" = 1 ]; then
  if have eslint && [ -d "$HERE/node_modules/eslint-plugin-security" ]; then
    es=1
  else
    section "ESLint (security)"; echo "  [SKIP] нужен eslint@8 + плагины в $HERE/node_modules (см. README)"; SKIPPED+=("ESLint (нет eslint@8/плагинов)")
  fi
else
  section "ESLint (security)"; echo "  [SKIP] выключен по умолчанию (включить: --eslint, нужен eslint@8). JS покрывают Semgrep+njsscan."; SKIPPED+=("ESLint (--eslint)")
fi
# cd в $TARGET, чтобы eslint видел относительные пути корректно (баг 6.x с '../' путями).
step_eslint(){ ( cd "$TARGET" && ESLINT_USE_FLAT_CONFIG=false eslint . --ext .js,.jsx --no-eslintrc \
  --resolve-plugins-relative-to "$HERE" -c "$HERE/configs/security.eslintrc.json" \
  --ignore-pattern 'node_modules/**' --ignore-pattern '**/*.min.js' --ignore-pattern 'dist/**' \
  -f json -o "$OUT/eslint.json" ) 2>&1 | tee "$LOG/eslint.log"; return "${PIPESTATUS[0]}"; }
[ "$es" = 1 ] && run_tool "ESLint (security)" 1 step_eslint "$OUT/eslint.json"

# ───────── 12. CodeQL (Java, buildless) — СБОРКА НЕ НУЖНА (--build-mode=none) ─────────
step_codeql(){
  # build-mode=none: извлечение из исходников без компиляции/Maven (CodeQL 2.16+ в свежем bundle).
  # --ram: CodeQL по умолчанию берёт мало heap → OOM. Берём ~80% доступной памяти (или CODEQL_RAM).
  # --threads: меньше потоков = меньше пиковая память (на слабой машине важнее скорости).
  local ram="${CODEQL_RAM:-}"
  if [ -z "$ram" ] && [ -r /proc/meminfo ]; then
    local kb; kb="$(awk '/MemAvailable/{print $2; exit}' /proc/meminfo 2>/dev/null)"
    [ -n "$kb" ] && ram=$(( kb / 1024 * 80 / 100 ))
  fi
  [ -z "$ram" ] && ram=2048
  local threads="${CODEQL_THREADS:-2}"
  echo "  (--ram=${ram}MB --threads=${threads}; переопредели CODEQL_RAM=МБ / CODEQL_THREADS=N. При OOM нужна машина с большим ОЗУ)"
  runlog codeql codeql database create "$OUT/codeql-db" --language=java --build-mode=none \
      --source-root "$TARGET" --overwrite --threads="$threads" --ram="$ram" \
    && runlog codeql codeql database analyze "$OUT/codeql-db" \
      codeql/java-queries:codeql-suites/java-security-extended.qls \
      --format=sarif-latest --threads="$threads" --ram="$ram" --output="$OUT/codeql-java.sarif"
}
if [ "$RUN_CODEQL" = 1 ]; then
  run_tool "CodeQL (Java, buildless)" "$(have codeql && echo 1 || echo 0)" step_codeql "$OUT/codeql-java.sarif"
else
  section "CodeQL (Java)"; echo "  [SKIP] тяжёлый; включить (сборка НЕ нужна, build-mode=none): --codeql"; SKIPPED+=("CodeQL (--codeql)")
fi

# ───────── 13. SpotBugs+FindSecBugs — нужен СКОМПИЛИРОВАННЫЙ байткод (.class/.jar) ─────────
step_spotbugs(){
  local classes; classes="$(find "$TARGET" -type d \( -path '*/target/classes' -o -path '*/build/classes' \) 2>/dev/null | head -20)"
  [ -z "$classes" ] && classes="$(find "$TARGET" -maxdepth 8 -name '*.jar' 2>/dev/null | head -80)"
  if [ -z "$classes" ]; then echo "  [SKIP] не найдено .class/.jar — нужен собранный проект (target/classes или *.ear/*.jar)"; return 0; fi
  runlog spotbugs spotbugs -textui -effort:max -pluginList "$FINDSECBUGS_PLUGIN" \
    -sarif -output "$OUT/spotbugs.sarif" $classes
}
if [ "$JAVA_BUILT" = 1 ]; then
  run_tool "SpotBugs+FindSecBugs" "$(have spotbugs && [ -n "${FINDSECBUGS_PLUGIN:-}" ] && echo 1 || echo 0)" step_spotbugs "$OUT/spotbugs.sarif"
else
  section "SpotBugs+FindSecBugs"; echo "  [SKIP] нужен байткод — соберите проект (target/classes или ct.ear), затем --java-built"; SKIPPED+=("SpotBugs (--java-built)")
fi

# ───────── Сведение отчётов ─────────
section "Сведение отчётов"
[ -f "$HERE/merge_reports.py" ] && "$PYTHON" "$HERE/merge_reports.py" "$OUT" || true
# Триаж + HTML (combined.sarif → triage-report.html + triaged.json). Подхватит _calibration.json, если положить рядом.
if [ -f "$HERE/make_triage_report.py" ] && [ -f "$OUT/combined.sarif" ]; then
  "$PYTHON" "$HERE/make_triage_report.py" "$OUT" --target "$TARGET" || true
fi

echo ""
echo "=================================================="
echo " Запущено  (${#RAN[@]}): ${RAN[*]:-—}"
echo " Пропущено (${#SKIPPED[@]}): ${SKIPPED[*]:-—}"
echo " С ошибкой (${#FAILED[@]}): ${FAILED[*]:-—}"
echo " Отчёты: $OUT"
echo "   triage-report.html · combined.sarif · SUMMARY.md · grep/report.md · logs/"
echo "=================================================="
