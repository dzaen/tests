# sec-audit-toolkit

Набор для статического анализа безопасности **Java backend + JavaScript/Node frontend**.
Рассчитан на авторизованный аудит собственного кода в **закрытом изолированном контуре**:
работает офлайн, без внешних зависимостей (только Python stdlib + опционально ripgrep).

> Это инструмент **триажа (recall)** — он показывает места для ручной проверки, а не
> доказывает уязвимость. Подтверждайте находки вручную и семантическими SAST
> (Semgrep taint-mode / CodeQL). Полный план — в [METHODOLOGY.md](METHODOLOGY.md).

## Состав

| Файл | Назначение |
|---|---|
| `security_scan.py` | Основной сканер. 150 regex-правил + энтропийный детектор секретов. Отчёты console / JSON / Markdown / SARIF. Только stdlib. |
| `rules.json` | База правил (Java + JS/Node + секреты). Человекочитаема — редактируйте/расширяйте напрямую. |
| `run-all.sh` | Оркестратор: запускает мой сканер + все доступные внешние SAST/SCA/секрет-сканеры (автодетект), сводит всё в `combined.sarif` + `SUMMARY.md`. |
| `merge_reports.py` | Агрегатор SARIF/JSON-отчётов в единый combined.sarif + сводку. |
| `quick-scan.sh` | Быстрый триаж через ripgrep (~30 топ-ROI паттернов), без Python. |
| `install/fetch-tools.sh` | (Снаружи, интернет) скачивает инструменты + правила Semgrep + БД CVE в `bundle/`. |
| `install/install-tools.sh` | (В контуре) ставит `bundle/` в `sectools/` и пишет `env.sh`. |
| `configs/security.eslintrc.json` | Конфиг ESLint с security-плагинами (для run-all.sh). |
| `METHODOLOGY.md` | Многослойная методология: инструменты (SAST/SCA/секреты), порядок проверки, чеклист ручной экспертизы. |
| `build_ruleset.py` | (Опционально) регенерация `rules.json` / `METHODOLOGY.md` из исходного набора. |

## Что нужно установить

- **Минимум (работает сразу):** `python3` — этого хватает для `security_scan.py`. Больше ничего.
- **`quick-scan.sh`:** ripgrep (`rg`).
- **`run-all.sh`:** ничего не требует сам — запускает только те внешние инструменты, что уже стоят в `PATH`,
  остальные пропускает. Полезные внешние: Semgrep (главный SAST), gitleaks (секреты), Trivy/OWASP Dependency-Check (зависимости),
  CodeQL/SpotBugs (нужна сборка Java). Их ставит `install/` (см. ниже).

## Air-gapped установка (Linux, через transfer-канал)

```bash
# 1) НА МАШИНЕ С ИНТЕРНЕТОМ: собрать bundle (базовый набор)
cd install && ./fetch-tools.sh                 # или --all для полного набора
#   wheels для Python-инструментов лучше тянуть на ОС/Python, совпадающих с контуром:
#   PY_VER=3.11 PLATFORM=manylinux2014_x86_64 ./fetch-tools.sh --all
#   для базы NVD задайте NVD_API_KEY=... (ускоряет в разы)

# 2) перенести каталог bundle/ в закрытый контур любым transfer-каналом

# 3) В КОНТУРЕ: установить из bundle (сеть не нужна)
./install-tools.sh /path/to/bundle             # ставит в ../sectools, пишет env.sh

# 4) запустить полный аудит (run-all сам подхватит sectools/env.sh)
cd .. && ./run-all.sh /path/to/code
```

Установка кладёт всё в локальный `sectools/` (бинари, venv, правила, БД) и не трогает систему.

**Если Semgrep падает с `ModuleNotFoundError: No module named 'pkg_resources'`** (venv на Python 3.12+ без setuptools):
```bash
./install/fix-semgrep-venv.sh           # офлайн: из bundle/wheels, иначе pip, иначе копия из системного Python
```

## Опциональные инструменты

- **CodeQL (глубокий taint, Java/JS) — сборка НЕ нужна:** `./run-all.sh /code --codeql` (режим `--build-mode=none`). Нужен установленный codeql-bundle.
- **SpotBugs (байткод):** нужен собранный проект (`target/classes` / `*.ear`), затем `--java-built`.
- **ESLint (security):** опционально. Поставь в каталог тулкита `eslint@8` + плагины (офлайн — перенеси `node_modules`):
  ```bash
  npm i --prefix . eslint@8 eslint-plugin-security eslint-plugin-no-unsanitized eslint-plugin-security-node
  ```
  После этого `run-all.sh` подхватит ESLint автоматически; без плагинов он чисто пропускается. JS и так покрывают Semgrep + njsscan.

## Запуск всех сканеров разом

```bash
./run-all.sh /path/to/code                 # автодетект: запускает что есть, пропускает остальное
./run-all.sh /path/to/code --quick         # + быстрый ripgrep-проход
./run-all.sh /path/to/code --grype         # + Grype (по умолчанию выкл. — медленный, дублирует Trivy/OSV)
./run-all.sh /path/to/code --java-built    # + CodeQL/SpotBugs (после сборки Java-проекта)
./run-all.sh /path/to/code --timeout 1800  # увеличить таймаут на инструмент (сек)
```
Все вызовы — строго офлайн (отключены сетевые обновления БД/правил, телеметрия, version-check, CISA KEV-фид и т.п.). Каждый инструмент с таймаутом; коды «найдены проблемы» не считаются ошибкой.
Результат: `report-<дата>/` с `combined.sarif` (все находки в одном SARIF), `SUMMARY.md`
(таблица по инструментам), `logs/` (полный вывод каждого сканера) и отчётами каждого сканера.
У каждого инструмента таймаут (по умолчанию 900с, `--timeout N`), прогресс виден на экране — ничего не виснет молча.

## Рекомендуемый способ доставки — один Docker-образ

Чтобы не собирать bundle из десятков файлов и не чинить venv в контуре — **соберите один образ снаружи и перенесите одним tar**. База `python:3.12` уже несёт `setuptools`, поэтому проблемы Semgrep с `pkg_resources` нет; CVE-базы Trivy/Grype запекаются внутрь.

```bash
# СНАРУЖИ (интернет): собрать и сохранить образ
bash docker/build-and-save.sh                 # + --java для PMD; --no-db чтобы не печь CVE-базы
# -> docker/dist/sec-audit-toolkit_1.0.tar.gz (+ .sha256)

# перенести этот один файл в контур, затем В КОНТУРЕ:
docker load < sec-audit-toolkit_1.0.tar.gz     # или podman load
bash docker/run.sh /path/to/code ./report      # запуск без сети (--network=none)
```

**Обновление** = пересобрать образ снаружи и перенести новый tar (раз в N недель). Само по себе обновления требуют в основном CVE-базы (Trivy/Grype/NVD) — инструменты и правила меняются редко.

## Быстрый старт

```bash
# 1. Полный скан, отчёты в ./sec-report (console + findings.json + report.md + results.sarif)
python security_scan.py /path/to/code -o sec-report

# 2. Только critical/high, с контекстом
python security_scan.py /path/to/code --min-severity high --context 2

# 3. Гейт для CI: ненулевой код возврата при наличии high+
python security_scan.py /path/to/code --fail-on high

# 4. Быстрый триаж без Python (нужен ripgrep)
bash quick-scan.sh /path/to/code

# 5. Посмотреть все правила
python security_scan.py --list-rules
```

Требования: Python 3.8+. Для `quick-scan.sh` — ripgrep (`apt/brew/choco install ripgrep`).

## Что покрывается

- **Java:** SQLi (JDBC/JPA/MyBatis), OS/LDAP/XPath/EL/SpEL/OGNL-инъекции, SSTI, reflection/ScriptEngine,
  десериализация (ObjectInputStream/XMLDecoder/Jackson/SnakeYAML/XStream), XXE, SSRF, path traversal,
  JNDI/Log4Shell, слабая крипта, JWT, Spring Security / CORS / Actuator.
- **JS/Node:** DOM XSS (innerHTML/document.write/dangerouslySetInnerHTML/v-html), `eval`/`Function`/`vm`,
  command injection (`child_process`), prototype pollution, NoSQL/SQL-инъекции, SSRF, небезопасные cookie/CORS,
  слабая крипта, открытые редиректы.
- **Контроль доступа / IDOR (кандидаты, needs-review):** идентификатор объекта из запроса
  (`@PathParam`/`@QueryParam`, `req.params/query/body.id`) + прямой доступ к объекту
  (`findById`/`em.find`/Mongoose `findOne`) без проверки владельца; роли/идентичность из HTTP-заголовка
  (паттерн «шлюз ставит `X-…-ROLES`»); доверие клиентскому полю роли/привилегии; mass assignment
  (`BeanUtils.copyProperties`/`@ModelAttribute`/`new Model(req.body)`). Греп помечает места — владение
  объектом проверяется вручную (см. подсказку «Как проверить» в HTML-отчёте).
- **Секреты:** AWS/GCP/Azure/GitHub/GitLab/Slack/Stripe/Twilio, приватные ключи (PEM), JWT,
  креды в строках подключения и URL, generic password/token-присваивания + энтропийный детектор.

## Снижение ложных срабатываний

- Секреты: ссылки на env (`process.env`, `System.getenv`, `${...}`, `@Value`) и плейсхолдеры
  (`CHANGEME`, `example`, `placeholder`) отсеиваются автоматически. Отключить: `--no-secret-fp`.
- Построчное подавление: добавьте комментарий `nosec` в строку с заведомо безопасным совпадением.
- Шумные эвристики (path traversal, SSRF-клиенты, prototype pollution и т.п.) понижены в severity —
  у каждого правила в `rules.json` есть поле `triage` с подсказкой, на что смотреть.

## Настройка

- Исключения каталогов/файлов: `--exclude-dir`, `--exclude-glob` (по умолчанию пропускаются
  `node_modules`, `dist`, `build`, `target`, `*.min.js`, lock-файлы и т.п.).
- Ограничение по типам: `--include-ext .java` (повторяемо).
- Новые правила: добавьте объект в `rules` в `rules.json` (`id`, `title`, `severity`,
  `languages`, `regex`, `why`, `remediation`; опционально `ignore_case`, `secret`, `category`).
```
